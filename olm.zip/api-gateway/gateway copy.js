// gateway.js
const fs = require('fs');
const https = require('https');
const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();

// SSL certs
const sslOptions = {
  key: fs.readFileSync('./cert/key.pem'),
  cert: fs.readFileSync('./cert/cert.pem'),
};

// Example proxy setup
app.use('/service1', createProxyMiddleware({
  target: 'http://localhost:3001', // downstream service
  changeOrigin: true,
  pathRewrite: { '^/service1': '' }
}));

app.use('/service2', createProxyMiddleware({
  target: 'http://localhost:3002',
  changeOrigin: true,
  pathRewrite: { '^/service2': '' }
}));

/**
 * https://192.168.133.91:8443/olm
 * https://192.168.133.91:8443/olm/api/tags
*/
app.use('/olm', createProxyMiddleware({
    target: 'http://localhost:11434',
    changeOrigin: true,
    pathRewrite: { '^/olm': '' }
}));
app.use('/secure', createProxyMiddleware({
  target: 'http://localhost',
  changeOrigin: true,
  pathRewrite: { '^/secure': '' }
}));


// Start HTTPS server
/* https.createServer(sslOptions, app).listen(443, () => {
  console.log('API Gateway running at https://localhost');
}); */

https.createServer(sslOptions, app).listen(8443, () => {
    console.log('API Gateway running at https://localhost:8443');
  });
