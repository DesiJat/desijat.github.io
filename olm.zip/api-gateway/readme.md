```sh
npm init -y
npm install express http-proxy-middleware
mkdir cert
openssl req -nodes -new -x509 -keyout cert/key.pem -out cert/cert.pem
```

api-gateway/
├── cert/
│   ├── key.pem       # Your private key
│   └── cert.pem      # Your certificate
├── gateway.js
└── package.json


```js
const http = require('http');
http.createServer((req, res) => {
  res.writeHead(301, { "Location": "https://" + req.headers['host'] + req.url });
  res.end();
}).listen(80);

```

https://localhost/service1/your-endpoint.

https://192.168.133.91:8443/secure/desijat.github.io/chat/audioCall/index.html
https://192.168.133.91:8443/olm