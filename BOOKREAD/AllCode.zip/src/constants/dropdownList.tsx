import i18n from "../i18n";
import { KookitConfig } from "../assets/lib/kookit-extra-browser.min";

export const fullTranslationLangList = (() => {
  const seen = new Set<string>();
  const options: { code: string; label: string }[] = [];
  for (const [code, label] of Object.entries(KookitConfig.ConvertLangMap)) {
    if (!seen.has(label)) {
      seen.add(label);
      options.push({ code, label });
    }
  }
  return options;
})();

export const codeHighlightLangList = [
  { label: "Disable", value: "" },
  { label: "JavaScript", value: "javascript" },
  { label: "TypeScript", value: "typescript" },
  { label: "Python", value: "python" },
  { label: "Go", value: "go" },
  { label: "Java", value: "java" },
  { label: "C", value: "c" },
  { label: "C++", value: "cpp" },
  { label: "C#", value: "csharp" },
  { label: "Rust", value: "rust" },
  { label: "Ruby", value: "ruby" },
  { label: "PHP", value: "php" },
  { label: "Swift", value: "swift" },
  { label: "Kotlin", value: "kotlin" },
  { label: "Bash", value: "bash" },
  { label: "Shell", value: "shell" },
  { label: "SQL", value: "sql" },
  { label: "JSON", value: "json" },
  { label: "YAML", value: "yaml" },
  { label: "Markdown", value: "markdown" },
  { label: "CSS", value: "css" },
  { label: "SCSS", value: "scss" },
  { label: "Less", value: "less" },
  { label: "XML", value: "xml" },
  { label: "GraphQL", value: "graphql" },
  { label: "Lua", value: "lua" },
  { label: "Perl", value: "perl" },
  { label: "R", value: "r" },
  { label: "Objective-C", value: "objectivec" },
  { label: "Makefile", value: "makefile" },
  { label: "Diff", value: "diff" },
  { label: "INI", value: "ini" },
  { label: "VB.NET", value: "vbnet" },
  { label: "WebAssembly", value: "wasm" },
];

export const dropdownList = [
  {
    title: "Book layout",
    value: "bookLayout",
    option: [
      { label: "Default", value: "" },
      { label: "Recommended layout", value: "kookit" },
      {
        label: "赫蹏",
        value: "heti",
      },
      { label: "漢字標準格式", value: "han" },
      { label: "中文网页重设与排版", value: "typo" },
      { label: "Tufte CSS", value: "tufte" },
      { label: "Typebase CSS", value: "typebase" },
    ],
    isPDF: false,
  },
  {
    title: "Code highlighting",
    value: "codeHighlight",
    option: codeHighlightLangList,
    isPDF: false,
  },
  {
    title: "Default font family",
    value: "fontFamily",
    option: [{ label: "Built-in font", value: "Built-in font" }],
    isPDF: false,
  },
  {
    title: "CJK font family",
    value: "subFontFamily",
    option: [{ label: "Built-in font", value: "Built-in font" }],
    isPDF: false,
  },
  {
    title: "Line height",
    value: "lineHeight",
    option: [
      { label: "Default", value: "" },
      { label: "1", value: "1" },
      { label: "1.25", value: "1.25" },
      { label: "1.5", value: "1.5" },
      { label: "1.75", value: "1.75" },
      { label: "2", value: "2" },
    ],
    isPDF: false,
  },
  {
    title: "Text alignment",
    value: "textAlign",
    option: [
      { label: "Default", value: "" },
      { label: "Left", value: "Left" },
      { label: "Justify", value: "Justify" },
      { label: "Right", value: "Right" },
    ],
    isPDF: false,
  },
  {
    title: "Text orientation",
    value: "textOrientation",
    option: [
      { label: "Default", value: "" },
      { label: "Horizontal", value: "horizontal" },
      { label: "Vertical", value: "vertical" },
    ],
    isPDF: false,
  },
  {
    title: "Conversion of Chinese",
    value: "convertChinese",
    option: [
      { label: "Default", value: "" },
      {
        label: "Simplified To Traditional",
        value: "Simplified To Traditional",
      },
      {
        label: "Traditional To Simplified",
        value: "Traditional To Simplified",
      },
    ],
    isPDF: false,
  },
  {
    title: "Page turning animation",
    value: "animation",
    option: [
      { label: "None", value: "none" },
      { label: "Slide", value: "sliding" },
      { label: "Flip", value: "mimical" },
    ],
    isPDF: true,
  },
  {
    title: "Action after selecting text",
    value: "selectAction",
    option: [
      { label: "Default", value: "" },
      {
        label: "Translate",
        value: "translation",
      },
      {
        label: "Dictionary",
        value: "dict",
      },
      {
        label: "Highlight",
        value: "highlight",
      },
      {
        label: "Take a note",
        value: "note",
      },
      {
        label: "Speak the text",
        value: "speaker",
      },
    ],
    isPDF: true,
  },
  {
    title: "Full text translation",
    value: "fullTranslationMode",
    option: [
      { label: "Disable", value: "no" },
      {
        label: "Bilingual translation",
        value: "both",
      },
      {
        label: "Only translation",
        value: "target",
      },
    ],
    isPDF: false,
  },
];
export const wordFrequencyList = [
  {
    title: "Chinese words level",
    value: "currentChineseLevel",
    option: [
      { label: "Default", value: "HSK3" },
      {
        label: "HSK1",
        value: "1",
      },
      {
        label: "HSK2",
        value: "2",
      },
      {
        label: "HSK3",
        value: "3",
      },
      {
        label: "HSK4",
        value: "4",
      },
      {
        label: "HSK5",
        value: "5",
      },
      {
        label: "HSK6",
        value: "6",
      },
      { label: "HSK7~9", value: "7~9" },
    ],
    isPDF: false,
  },
  {
    title: "Japanese words level",
    value: "currentJapaneseLevel",
    option: [
      { label: "Default", value: "N3" },
      { label: "N5", value: "N5" },
      { label: "N4", value: "N4" },
      { label: "N3", value: "N3" },
      { label: "N2", value: "N2" },
      { label: "N1", value: "N1" },
    ],
    isPDF: false,
  },
  {
    title: "English words level",
    value: "currentEnglishLevel",
    option: [
      { label: "Default", value: "四级" },
      { label: "小学", value: "小学" },
      { label: "初中", value: "初中" },
      { label: "高中", value: "高中" },
      { label: "四级", value: "四级" },
      { label: "六级", value: "六级" },
      { label: "专四专八", value: "专四专八" },
      { label: "GRE", value: "GRE" },
    ],
    isPDF: false,
  },
];
export const sliderConfigs = [
  {
    maxValue: 40,
    minValue: 13,
    mode: "fontSize",
    minLabel: "13",
    maxLabel: "40",
    step: 1,
    title: "Font size",
    isPDF: false,
  },
  {
    maxValue: 80,
    minValue: -40,
    mode: "margin",
    minLabel: "-40",
    maxLabel: "80",
    step: 5,
    title: "Margin",
    isPDF: true,
  },
  {
    maxValue: 20,
    minValue: 0,
    mode: "letterSpacing",
    minLabel: "0",
    maxLabel: "20",
    step: 1,
    title: "Letter spacing",
    isPDF: false,
  },
  {
    maxValue: 120,
    minValue: 0,
    mode: "paraSpacing",
    minLabel: "0",
    maxLabel: "120",
    step: 1,
    title: "Paragraph spacing",
    isPDF: false,
  },
  {
    maxValue: 3,
    minValue: 0.5,
    mode: "scale",
    minLabel: "0.5",
    maxLabel: "3",
    step: 0.1,
    title: "Page width",
    isPDF: true,
  },
  {
    maxValue: 1,
    minValue: 0.3,
    mode: "brightness",
    minLabel: "0.3",
    maxLabel: "1",
    step: 0.1,
    title: "Brightness",
    isPDF: true,
  },
];
export const speedList = {
  id: 3,
  title: "Speed",
  value: "speed",
  option: [
    { label: "0.1", value: "0.1" },
    { label: "0.2", value: "0.2" },
    { label: "0.3", value: "0.3" },
    { label: "0.4", value: "0.4" },
    { label: "0.5", value: "0.5" },
    { label: "0.75", value: "0.75" },
    { label: "1", value: "1" },
    { label: "1.25", value: "1.25" },
    { label: "1.5", value: "1.5" },
    { label: "1.75", value: "1.75" },
    { label: "2", value: "2" },
    { label: "3", value: "3" },
    { label: "4", value: "4" },
    { label: "5", value: "5" },
    { label: "6", value: "6" },
    { label: "7", value: "7" },
    { label: "8", value: "8" },
  ],
};
export const ocrTesseractLangList = [
  { label: "Simplified Chinese", value: "chi_sim", lang: "zhCN" },
  { label: "Traditional Chinese", value: "chi_tra", lang: "zhTW" },
  { label: "English", value: "eng", lang: "en" },
  { label: "Japanese", value: "jpn", lang: "ja" },
  { label: "Korean", value: "kor", lang: "ko" },
  { label: "French", value: "fra", lang: "fr" },
  { label: "German", value: "deu", lang: "de" },
  { label: "Spanish", value: "spa", lang: "es" },
  { label: "Russian", value: "rus", lang: "ru" },
  { label: "Italian", value: "ita", lang: "it" },
  { label: "Portuguese", value: "por", lang: "pt" },
];
export const getOcrPaddleLangList = () => [
  {
    label: `${i18n.t("General")} (${i18n.t("Chinese")},${i18n.t("English")},${i18n.t("Japanese")})`,
    value: "standard_v5_mobile",
    lang: "standard_v5_mobile",
  },
  {
    label: `${i18n.t("Chinese")} (${i18n.t("More accurate")})`,
    value: "fast_ch",
    lang: "fast_ch",
  },
  {
    label: `${i18n.t("English")} (${i18n.t("More accurate")})`,
    value: "en",
    lang: "en",
  },
  {
    label: `${i18n.t("Traditional Chinese")} (${i18n.t("More accurate")})`,
    value: "chinese_cht",
    lang: "chinese_cht",
  },
  {
    label: `${i18n.t("Japanese")} (${i18n.t("More accurate")})`,
    value: "japan",
    lang: "japan",
  },
  {
    label: i18n.t("Korean"),
    value: "korean",
    lang: "korean",
  },
];
export const paraSpacingList = [
  { label: "1", value: "1" },
  { label: "1.1", value: "1.1" },
  { label: "1.2", value: "1.2" },
  { label: "1.3", value: "1.3" },
  { label: "1.4", value: "1.4" },
  { label: "1.5", value: "1.5" },
  { label: "2", value: "2" },
  { label: "3", value: "3" },
  { label: "4", value: "4" },
  { label: "5", value: "5" },
];
export const titleSizeList = [
  { label: "1", value: "1" },
  { label: "1.1", value: "1.1" },
  { label: "1.2", value: "1.2" },
  { label: "1.3", value: "1.3" },
  { label: "1.4", value: "1.4" },
  { label: "1.5", value: "1.5" },
  { label: "2", value: "2" },
  { label: "3", value: "3" },
  { label: "4", value: "4" },
  { label: "5", value: "5" },
];
export const ocrEngineList = [
  { label: "Please select", value: "", lang: "" },
  {
    label: "Official AI OCR",
    value: "official-ai-ocr",
    lang: "general",
    isPro: true,
  },
  {
    label: "System OCR",
    value: "system-ocr",
    lang: "auto",
  },
  {
    label: "Paddle OCR",
    value: "paddle",
    lang: "standard_v5_mobile",
  },
  {
    label: "Tesseract",
    value: "tesseract",
    lang: "chi_sim",
  },
];
