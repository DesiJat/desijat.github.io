import React from "react";
import BookModel from "../../models/Book";
import "./selectBook.css";
import { Trans } from "react-i18next";
import { BookListProps, BookListState } from "./interface";
import { withRouter } from "react-router-dom";
import toast from "react-hot-toast";
import {
  BOOK_EXPORT_FORMATS,
  exportBooksAs,
  exportDictionaryHistory,
  exportHighlights,
  exportNotes,
} from "../../utils/file/export";
import BookUtil from "../../utils/file/bookUtil";
import { ConfigService } from "../../assets/lib/kookit-extra-browser.min";
import DatabaseService from "../../utils/storage/databaseService";
import { preCacheAllBooks } from "../../utils/common";
class SelectBook extends React.Component<BookListProps, BookListState> {
  constructor(props: BookListProps) {
    super(props);
    this.state = {
      isOpenDelete: false,
      isShowExport: false,
      exportSubmenu: "",
      favoriteBooks: Object.keys(
        ConfigService.getAllListConfig("favoriteBooks")
      ).length,
    };
  }
  handleFilterShelfBook = (items: BookModel[]) => {
    if (this.props.shelfTitle) {
      let currentShelfTitle = this.props.shelfTitle;
      if (!currentShelfTitle) return items;
      let currentShelfList = ConfigService.getMapConfig(
        currentShelfTitle,
        "shelfList"
      );
      let shelfItems = items.filter((item: BookModel) => {
        return currentShelfList.indexOf(item.key) > -1;
      });
      return shelfItems;
    } else {
      if (ConfigService.getReaderConfig("isHideShelfBook") === "yes") {
        return items.filter((item) => {
          return (
            ConfigService.getFromAllMapConfig(item.key, "shelfList").length ===
            0
          );
        });
      }
      return items;
    }
  };
  handleShelf(items: any, index: number) {
    if (index < 1) return items;
    let shelfTitle = Object.keys(ConfigService.getAllMapConfig("shelfList"));
    let currentShelfTitle = shelfTitle[index];
    if (!currentShelfTitle) return items;
    let currentShelfList = ConfigService.getMapConfig(
      currentShelfTitle,
      "shelfList"
    );
    let shelfItems = items.filter((item: { key: number }) => {
      return currentShelfList.indexOf(item.key) > -1;
    });
    return shelfItems;
  }
  handleIndexFilter = (items: any, arr: number[]) => {
    let itemArr: any[] = [];
    arr.forEach((item) => {
      items[item] && itemArr.push(items[item]);
    });
    return itemArr;
  };

  renderBookFormatSubmenu = () => {
    const formatLabels = {
      md: "Markdown (.md)",
      txt: "TXT (.txt)",
      json: "JSON (.json)",
      pdf: "PDF (.pdf)",
    } as const;
    return (
      <div
        className="select-more-actions select-export-format-submenu"
        style={
          this.state.exportSubmenu === "books"
            ? { left: "160px", bottom: "auto", top: "0px" }
            : { display: "none" }
        }
        onMouseEnter={() => {
          this.setState({ exportSubmenu: "books", isShowExport: true });
        }}
        onMouseLeave={() => {
          this.setState({ exportSubmenu: "", isShowExport: false });
        }}
      >
        {BOOK_EXPORT_FORMATS.map((format) => (
          <span
            key={format}
            className="book-manage-title select-book-action"
            onClick={async () => {
              const selectedBooks = await DatabaseService.getRecordsByKeys(
                this.props.selectedBooks,
                "books"
              );
              const exported = await exportBooksAs(selectedBooks, format);
              if (exported) toast.success(this.props.t("Export successful"));
              this.setState({ exportSubmenu: "", isShowExport: false });
            }}
          >
            {this.props.t(formatLabels[format])}
          </span>
        ))}
      </div>
    );
  };

  render() {
    return (
      <div
        className="booklist-manage-container"
        style={this.props.isCollapsed ? { left: "75px" } : {}}
      >
        {this.props.isSelectBook && (
          <>
            <span
              onClick={() => {
                this.props.handleSelectBook(!this.props.isSelectBook);
                if (this.props.isSelectBook) {
                  this.props.handleSelectedBooks([]);
                }
              }}
              className="book-manage-title"
              style={{ color: "rgb(231, 69, 69)" }}
            >
              <Trans>Cancel</Trans>
            </span>
            <span
              className="book-manage-title"
              onClick={() => {
                if (
                  this.props.books.filter(
                    (item: BookModel) =>
                      this.props.selectedBooks.indexOf(item.key) > -1
                  ).length > 0
                ) {
                  this.props.selectedBooks.forEach((item) => {
                    ConfigService.setListConfig(item, "favoriteBooks");
                  });

                  this.props.handleSelectBook(!this.props.isSelectBook);
                  if (this.props.isSelectBook) {
                    this.props.handleSelectedBooks([]);
                  }
                  toast.success(this.props.t("Add successful"));
                } else {
                  toast(this.props.t("Nothing to add"));
                }
              }}
            >
              <Trans>Add to favorite</Trans>
            </span>
            <span
              className="book-manage-title"
              onClick={() => {
                this.props.handleAddDialog(true);
              }}
            >
              <Trans>Add to shelf</Trans>
            </span>
            <span
              className="book-manage-title"
              onClick={() => {
                this.props.handleDeleteDialog(true);
              }}
            >
              <Trans>Delete</Trans>
            </span>
            <div className="select-more-actions-container">
              <span
                className="book-manage-title"
                onMouseEnter={() => {
                  this.setState({ isShowExport: true });
                }}
                onMouseLeave={(event) => {
                  this.setState({ isShowExport: false });
                  event.stopPropagation();
                }}
              >
                <Trans>More actions</Trans>
              </span>

              <div
                className="select-more-actions"
                style={this.state.isShowExport ? {} : { display: "none" }}
                onMouseLeave={() => {
                  this.setState({ isShowExport: false });
                }}
                onMouseEnter={(event) => {
                  this.setState({ isShowExport: true });
                  event?.stopPropagation();
                }}
              >
                <div style={{ position: "relative" }}>
                  <span
                    className="book-manage-title select-book-action"
                    onMouseEnter={() => {
                      this.setState({
                        exportSubmenu: "books",
                        isShowExport: true,
                      });
                    }}
                    onMouseLeave={() => {
                      this.setState({ exportSubmenu: "" });
                    }}
                  >
                    <Trans>Export books</Trans>
                    <span className="icon-dropdown icon-export-all"></span>
                  </span>
                  {this.renderBookFormatSubmenu()}
                </div>
                <div style={{ position: "relative" }}>
                  <span
                    className="book-manage-title select-book-action"
                    onMouseEnter={() => {
                      this.setState({
                        exportSubmenu: "notes",
                        isShowExport: true,
                      });
                    }}
                    onMouseLeave={() => {
                      this.setState({ exportSubmenu: "" });
                    }}
                  >
                    <Trans>Export notes</Trans>
                    <span className="icon-dropdown icon-export-all"></span>
                  </span>
                  <div
                    className="select-more-actions select-export-format-submenu"
                    style={
                      this.state.exportSubmenu === "notes"
                        ? { left: "160px", bottom: "auto", top: "0px" }
                        : { display: "none" }
                    }
                    onMouseEnter={() => {
                      this.setState({
                        exportSubmenu: "notes",
                        isShowExport: true,
                      });
                    }}
                    onMouseLeave={() => {
                      this.setState({ exportSubmenu: "", isShowExport: false });
                    }}
                  >
                    {(["csv", "md", "txt", "html", "pdf"] as const).map(
                      (fmt) => (
                        <span
                          key={fmt}
                          className="book-manage-title select-book-action"
                          onClick={async () => {
                            let selectedBooks =
                              await DatabaseService.getRecordsByKeys(
                                this.props.selectedBooks,
                                "books"
                              );
                            let notes = (
                              await DatabaseService.getRecordsByBookKeys(
                                this.props.selectedBooks,
                                "notes"
                              )
                            ).filter(
                              (note) =>
                                note.notes !== "" &&
                                note.notes !== "annotation"
                            );
                            if (notes.length > 0) {
                              exportNotes(notes, selectedBooks, fmt);
                              toast.success(this.props.t("Export successful"));
                            } else {
                              toast(this.props.t("Nothing to export"));
                            }
                            this.setState({
                              exportSubmenu: "",
                              isShowExport: false,
                            });
                          }}
                        >
                          {fmt === "csv"
                            ? "CSV"
                            : fmt === "md"
                              ? "Markdown"
                              : fmt === "txt"
                                ? "TXT"
                                : fmt === "html"
                                  ? "HTML"
                                  : "PDF"}
                        </span>
                      )
                    )}
                  </div>
                </div>
                <div style={{ position: "relative" }}>
                  <span
                    className="book-manage-title select-book-action"
                    onMouseEnter={() => {
                      this.setState({
                        exportSubmenu: "highlights",
                        isShowExport: true,
                      });
                    }}
                    onMouseLeave={() => {
                      this.setState({ exportSubmenu: "" });
                    }}
                  >
                    <Trans>Export highlights</Trans>
                    <span className="icon-dropdown icon-export-all"></span>
                  </span>
                  <div
                    className="select-more-actions select-export-format-submenu"
                    style={
                      this.state.exportSubmenu === "highlights"
                        ? { left: "160px", bottom: "auto", top: "0px" }
                        : { display: "none" }
                    }
                    onMouseEnter={() => {
                      this.setState({
                        exportSubmenu: "highlights",
                        isShowExport: true,
                      });
                    }}
                    onMouseLeave={() => {
                      this.setState({ exportSubmenu: "", isShowExport: false });
                    }}
                  >
                    {(["csv", "md", "txt", "html", "pdf"] as const).map(
                      (fmt) => (
                        <span
                          key={fmt}
                          className="book-manage-title select-book-action"
                          onClick={async () => {
                            let selectedBooks =
                              await DatabaseService.getRecordsByKeys(
                                this.props.selectedBooks,
                                "books"
                              );
                            let highlights = (
                              await DatabaseService.getRecordsByBookKeys(
                                this.props.selectedBooks,
                                "notes"
                              )
                            ).filter((note) => note.notes === "");
                            if (highlights.length > 0) {
                              exportHighlights(highlights, selectedBooks, fmt);
                              toast.success(this.props.t("Export successful"));
                            } else {
                              toast(this.props.t("Nothing to export"));
                            }
                            this.setState({
                              exportSubmenu: "",
                              isShowExport: false,
                            });
                          }}
                        >
                          {fmt === "csv"
                            ? "CSV"
                            : fmt === "md"
                              ? "Markdown"
                              : fmt === "txt"
                                ? "TXT"
                                : fmt === "html"
                                  ? "HTML"
                                  : "PDF"}
                        </span>
                      )
                    )}
                  </div>
                </div>
                <span
                  className="book-manage-title select-book-action"
                  onClick={async () => {
                    let selectedBooks = await DatabaseService.getRecordsByKeys(
                      this.props.selectedBooks,
                      "books"
                    );
                    let dictHistory =
                      await DatabaseService.getRecordsByBookKeys(
                        this.props.selectedBooks,
                        "words"
                      );
                    if (dictHistory.length > 0) {
                      exportDictionaryHistory(dictHistory, selectedBooks);
                      toast.success(this.props.t("Export successful"));
                    } else {
                      toast(this.props.t("Nothing to export"));
                    }
                  }}
                >
                  <Trans>Export dictionary history</Trans>
                </span>
                <span
                  className="book-manage-title select-book-action"
                  onClick={async () => {
                    let selectedBooks = await DatabaseService.getRecordsByKeys(
                      this.props.selectedBooks,
                      "books"
                    );
                    if (selectedBooks.length > 0) {
                      await preCacheAllBooks(selectedBooks);
                      toast.success(this.props.t("Pre-caching successful"));
                    } else {
                      toast(this.props.t("Nothing to precache"));
                    }
                  }}
                >
                  <Trans>Pre-cache</Trans>
                </span>
                <span
                  className="book-manage-title select-book-action"
                  onClick={async () => {
                    let selectedBooks = await DatabaseService.getRecordsByKeys(
                      this.props.selectedBooks,
                      "books"
                    );
                    if (selectedBooks.length === 0) {
                      toast(this.props.t("Nothing to delete"));
                      return;
                    }
                    for (let index = 0; index < selectedBooks.length; index++) {
                      const selectedBook = selectedBooks[index];
                      await BookUtil.deleteBook(
                        "cache-" + selectedBook.key,
                        "zip"
                      );
                      toast.success(this.props.t("Deletion successful"));
                    }
                  }}
                >
                  <Trans>Delete pre-cache</Trans>
                </span>
              </div>
            </div>

            <span
              className="book-manage-title"
              onClick={() => {
                if (this.props.isSearch) {
                  this.props.handleSelectedBooks(
                    this.props.searchResults.map((item) => item.key)
                  );
                } else if (
                  this.props.selectedBooks.length ===
                  this.handleFilterShelfBook(this.props.books).length
                ) {
                  this.props.handleSelectedBooks([]);
                } else {
                  this.props.handleSelectedBooks(
                    this.handleFilterShelfBook(this.props.books).map(
                      (item) => item.key
                    )
                  );
                }
              }}
            >
              {this.props.selectedBooks.length ===
              this.handleFilterShelfBook(this.props.books).length ? (
                <Trans>Deselect all</Trans>
              ) : (
                <Trans>Select all</Trans>
              )}
            </span>
          </>
        )}
      </div>
    );
  }
}

export default withRouter(SelectBook as any);
