import React from "react";
import { backgroundList, textList } from "../../../constants/themeList";
import StyleUtil from "../../../utils/reader/styleUtil";
import "./themeList.css";
import { Trans } from "react-i18next";
import { ThemeListProps, ThemeListState } from "./interface";
import {
  ConfigService,
  KookitConfig,
} from "../../../assets/lib/kookit-extra-browser.min";
import { HexColorPicker } from "react-colorful";
import toast from "react-hot-toast";
import { normalizePickerColor, parseColorInput } from "../../../utils/common";

class ThemeList extends React.Component<ThemeListProps, ThemeListState> {
  constructor(props: ThemeListProps) {
    super(props);
    this.state = {
      currentBackgroundIndex: backgroundList
        .concat(ConfigService.getAllListConfig("themeColors"))
        .findIndex((item) => {
          return (
            item ===
            (ConfigService.getReaderConfig("backgroundColor") ||
              "rgba(255,255,255,1)")
          );
        }),
      currentTextIndex: textList
        .concat(ConfigService.getAllListConfig("themeColors"))
        .findIndex((item) => {
          return (
            item ===
            (ConfigService.getReaderConfig("textColor") || "rgba(0,0,0,1)")
          );
        }),
      isShowTextPicker: false,
      isShowBgPicker: false,
      currentPresetIndex: KookitConfig.PresetThemeList.findIndex((item) => {
        return (
          item.backgroundColor ===
            (ConfigService.getReaderConfig("backgroundColor") ||
              "rgba(255,255,255,1)") &&
          item.textColor ===
            (ConfigService.getReaderConfig("textColor") || "rgba(0,0,0,1)")
        );
      }),
      bgColorInput: normalizePickerColor(
        ConfigService.getReaderConfig("backgroundColor"),
        "#ffffff"
      ),
      textColorInput: normalizePickerColor(
        ConfigService.getReaderConfig("textColor"),
        "#000000"
      ),
      pendingBgColor: normalizePickerColor(
        ConfigService.getReaderConfig("backgroundColor"),
        "#ffffff"
      ),
      pendingTextColor: normalizePickerColor(
        ConfigService.getReaderConfig("textColor"),
        "#000000"
      ),
    };
  }
  handleChangeBgColor = (color: string, index: number = -1) => {
    ConfigService.setReaderConfig("backgroundColor", color);
    this.props.handleBackgroundColor(color);
    this.setState({
      currentBackgroundIndex: index,
    });
    if (index === 1) {
      ConfigService.setReaderConfig("textColor", "rgba(255,255,255,1)");
    } else if (
      index === 0 &&
      ConfigService.getReaderConfig("backgroundColor") === "rgba(255,255,255,1)"
    ) {
      ConfigService.setReaderConfig("textColor", "rgba(0,0,0,1)");
    }
    this.props.renderBookFunc();
    this.setState({
      currentPresetIndex: this.getPresetIndex(
        color,
        ConfigService.getReaderConfig("textColor") || "rgba(0,0,0,1)"
      ),
    });
  };

  handlePreviewBgColor = (color: string) => {
    this.setState({ bgColorInput: color, pendingBgColor: color });
  };
  handlePreviewTextColor = (color: string) => {
    this.setState({ textColorInput: color, pendingTextColor: color });
  };
  handleColorTextPicker = (isShowTextPicker: boolean) => {
    if (!isShowTextPicker) {
      const pendingHex = this.state.pendingTextColor;
      const exists = textList
        .concat(ConfigService.getAllListConfig("themeColors"))
        .some((item) => normalizePickerColor(item, "#000000") === pendingHex);
      if (!exists) {
        ConfigService.setListConfig(pendingHex, "themeColors");
      }
      const appliedColor =
        ConfigService.getReaderConfig("textColor") || "rgba(0,0,0,1)";
      this.setState({
        currentTextIndex: textList
          .concat(ConfigService.getAllListConfig("themeColors"))
          .indexOf(appliedColor),
      });
    } else {
      const current = normalizePickerColor(
        ConfigService.getReaderConfig("textColor"),
        "#000000"
      );
      this.setState({
        pendingTextColor: current,
        textColorInput: current,
      });
    }
    this.setState({ isShowTextPicker });
  };
  handleColorBgPicker = (isShowBgPicker: boolean) => {
    if (!isShowBgPicker) {
      const pendingHex = this.state.pendingBgColor;
      const exists = backgroundList
        .concat(ConfigService.getAllListConfig("themeColors"))
        .some((item) => normalizePickerColor(item, "#ffffff") === pendingHex);
      if (!exists) {
        ConfigService.setListConfig(pendingHex, "themeColors");
      }
      const appliedColor =
        ConfigService.getReaderConfig("backgroundColor") ||
        "rgba(255,255,255,1)";
      this.setState({
        currentBackgroundIndex: backgroundList
          .concat(ConfigService.getAllListConfig("themeColors"))
          .indexOf(appliedColor),
      });
    } else {
      const current = normalizePickerColor(
        ConfigService.getReaderConfig("backgroundColor"),
        "#ffffff"
      );
      this.setState({
        pendingBgColor: current,
        bgColorInput: current,
      });
    }
    this.setState({ isShowBgPicker });
  };
  handleChooseTextColor = (color: string) => {
    this.setState({
      currentTextIndex: textList
        .concat(ConfigService.getAllListConfig("themeColors"))
        .indexOf(color),
      textColorInput: normalizePickerColor(color, "#000000"),
      pendingTextColor: normalizePickerColor(color, "#000000"),
      currentPresetIndex: this.getPresetIndex(
        ConfigService.getReaderConfig("backgroundColor") ||
          "rgba(255,255,255,1)",
        color
      ),
    });
    ConfigService.setReaderConfig("textColor", color);
    this.props.renderBookFunc();
  };
  getPresetIndex = (backgroundColor: string, textColor: string) => {
    return KookitConfig.PresetThemeList.findIndex((item) => {
      return (
        item.backgroundColor === backgroundColor && item.textColor === textColor
      );
    });
  };
  handleChoosePreset = (
    preset: { textColor: string; backgroundColor: string },
    index: number
  ) => {
    ConfigService.setReaderConfig("backgroundColor", preset.backgroundColor);
    ConfigService.setReaderConfig("textColor", preset.textColor);
    this.props.handleBackgroundColor(preset.backgroundColor);
    const bgIndex = backgroundList
      .concat(ConfigService.getAllListConfig("themeColors"))
      .indexOf(preset.backgroundColor);
    const textIndex = textList
      .concat(ConfigService.getAllListConfig("themeColors"))
      .indexOf(preset.textColor);
    this.setState({
      currentBackgroundIndex: bgIndex,
      currentTextIndex: textIndex,
      currentPresetIndex: index,
      bgColorInput: normalizePickerColor(preset.backgroundColor, "#ffffff"),
      textColorInput: normalizePickerColor(preset.textColor, "#000000"),
    });
    this.props.renderBookFunc();
  };
  render() {
    const renderBackgroundColorList = () => {
      return backgroundList
        .concat(ConfigService.getAllListConfig("themeColors"))
        .map((item, index) => {
          return (
            <li
              key={item + index}
              className={
                index === this.state.currentBackgroundIndex
                  ? "active-color background-color-circle"
                  : "background-color-circle"
              }
              onClick={() => {
                this.handleChangeBgColor(item, index);
              }}
              style={{ backgroundColor: item }}
            >
              {index > 3 && (
                <span
                  className="icon-close theme-color-delete theme-color-delete-hover theme-color-delete-button"
                  onClick={(e) => {
                    e.stopPropagation();
                    ConfigService.deleteListConfig(item, "themeColors");
                    if (index === this.state.currentBackgroundIndex) {
                      this.handleChangeBgColor(backgroundList[0], 0);
                    } else {
                      this.forceUpdate();
                    }
                  }}
                ></span>
              )}
            </li>
          );
        });
    };
    const renderTextColorList = () => {
      return textList
        .concat(ConfigService.getAllListConfig("themeColors"))
        .map((item, index) => {
          return (
            <li
              key={item + index}
              className={
                index === this.state.currentTextIndex
                  ? "active-color background-color-circle"
                  : "background-color-circle"
              }
              onClick={() => {
                this.handleChooseTextColor(item);
              }}
              style={{ backgroundColor: item }}
            >
              {index > 3 && (
                <span
                  className="icon-close theme-color-delete theme-color-delete-hover"
                  onClick={(e) => {
                    e.stopPropagation();
                    ConfigService.deleteListConfig(item, "themeColors");
                    if (index === this.state.currentTextIndex) {
                      this.handleChooseTextColor(textList[0]);
                    } else {
                      this.forceUpdate();
                    }
                  }}
                ></span>
              )}
            </li>
          );
        });
    };
    return (
      <div className="background-color-setting">
        <div
          className="background-color-text"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
          }}
        >
          <Trans>Background color</Trans>
          <span
            className="theme-color-clear-button"
            onClick={() => {
              ConfigService.setReaderConfig("backgroundColor", "");
              this.props.handleBackgroundColor("");
              toast.success(this.props.t("Removal successful"));
              this.props.renderBookFunc();
            }}
          >
            <Trans>Clear</Trans>{" "}
            <span className="icon-trash" style={{ fontSize: "13px" }}></span>
          </span>
        </div>
        <ul className="background-color-list">
          <li
            className="background-color-circle"
            onClick={() => {
              this.handleColorBgPicker(!this.state.isShowBgPicker);
            }}
          >
            <span
              className={this.state.isShowBgPicker ? "icon-check" : "icon-more"}
            ></span>
          </li>

          {renderBackgroundColorList()}
        </ul>
        {this.state.isShowBgPicker && (
          <div style={{ margin: "10px 20px", marginLeft: "30px" }}>
            <HexColorPicker
              color={this.state.pendingBgColor}
              onChange={this.handlePreviewBgColor}
              style={{
                marginBottom: 10,
                animation: "fade-in 0.2s ease-in-out 0s 1",
              }}
            />
            <input
              className="color-input-box"
              value={this.state.bgColorInput}
              placeholder="#rrggbb / rgba(r,g,b,a)"
              onChange={(e) =>
                this.setState({ bgColorInput: e.target.value })
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  const hex = parseColorInput(this.state.bgColorInput);
                  if (hex) this.handlePreviewBgColor(hex);
                }
              }}
              onBlur={() => {
                const hex = parseColorInput(this.state.bgColorInput);
                if (hex) this.handlePreviewBgColor(hex);
                else
                  this.setState({
                    bgColorInput: this.state.pendingBgColor,
                  });
              }}
            />
          </div>
        )}
        <div
          className="background-color-text"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
          }}
        >
          <Trans>Text color</Trans>
          <span
            className="theme-color-clear-button"
            onClick={() => {
              ConfigService.setReaderConfig("textColor", "");
              toast.success(this.props.t("Removal successful"));
              this.props.renderBookFunc();
            }}
          >
            <Trans>Clear</Trans>{" "}
            <span className="icon-trash" style={{ fontSize: "13px" }}></span>
          </span>
        </div>
        <ul className="background-color-list">
          <li
            className="background-color-circle"
            onClick={() => {
              this.handleColorTextPicker(!this.state.isShowTextPicker);
            }}
          >
            <span
              className={
                this.state.isShowTextPicker ? "icon-check" : "icon-more"
              }
            ></span>
          </li>

          {renderTextColorList()}
        </ul>
        {this.state.isShowTextPicker && (
          <div style={{ margin: "10px 20px", marginLeft: "30px" }}>
            <HexColorPicker
              color={this.state.pendingTextColor}
              onChange={this.handlePreviewTextColor}
              style={{
                marginBottom: 10,
                animation: "fade-in 0.2s ease-in-out 0s 1",
              }}
            />
            <input
              className="color-input-box"
              value={this.state.textColorInput}
              placeholder="#rrggbb / rgba(r,g,b,a)"
              onChange={(e) =>
                this.setState({ textColorInput: e.target.value })
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  const hex = parseColorInput(this.state.textColorInput);
                  if (hex) this.handlePreviewTextColor(hex);
                }
              }}
              onBlur={() => {
                const hex = parseColorInput(this.state.textColorInput);
                if (hex) this.handlePreviewTextColor(hex);
                else
                  this.setState({
                    textColorInput: this.state.pendingTextColor,
                  });
              }}
            />
          </div>
        )}
        <div
          className="background-color-text"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
          }}
        >
          <Trans>Theme</Trans>
        </div>
        <div className="preset-theme-list">
          {KookitConfig.PresetThemeList.map((item, index) => {
            return (
              <div
                key={item.key}
                className={"preset-theme-item"}
                style={{
                  backgroundColor: item.backgroundColor,
                  color: item.textColor,
                  borderColor: item.textColor,
                }}
                onClick={() => {
                  this.handleChoosePreset(item, index);
                }}
              >
                <span className="preset-theme-text">
                  {(ConfigService.getReaderConfig("lang") || "").startsWith(
                    "zh"
                  )
                    ? this.props.t(item.title)
                    : "A"}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    );
  }
}

export default ThemeList;
