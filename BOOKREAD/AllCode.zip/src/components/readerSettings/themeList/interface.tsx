import Book from "../../../models/Book";

export interface ThemeListProps {
  t: (title: string) => string;
  currentBook: Book;
  renderBookFunc: () => void;
  handleBackgroundColor: (color: string) => void;
}

export interface ThemeListState {
  currentBackgroundIndex: number;
  currentTextIndex: number;
  currentPresetIndex: number;
  isShowTextPicker: boolean;
  isShowBgPicker: boolean;
  bgColorInput: string;
  textColorInput: string;
  pendingBgColor: string;
  pendingTextColor: string;
}
