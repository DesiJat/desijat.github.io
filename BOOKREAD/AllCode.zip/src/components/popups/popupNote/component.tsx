import React from "react";
import "./popupNote.css";
import Note from "../../../models/Note";
import _ from "underscore";
import { PopupNoteProps, PopupNoteState } from "./interface";
import NoteTag from "../../noteTag";
import { Trans } from "react-i18next";
import toast from "react-hot-toast";
import { getIframeDoc } from "../../../utils/reader/docUtil";
import {
  ConfigService,
  HighlightUtil,
  NoteSyncManager,
} from "../../../assets/lib/kookit-extra-browser.min";
import DatabaseService from "../../../utils/storage/databaseService";
import ColorOption from "../../colorOption";
import copy from "copy-text-to-clipboard";
class PopupNote extends React.Component<PopupNoteProps, PopupNoteState> {
  highlightUtil: any;
  constructor(props: PopupNoteProps) {
    super(props);
    this.highlightUtil = new HighlightUtil(ConfigService);
    this.state = { tag: [], text: "", note: null };
  }
  async componentDidMount() {
    let textArea: any = document.querySelector(".editor-box");
    textArea && textArea.focus();
    if (this.props.noteKey) {
      let note: Note = await DatabaseService.getRecord(
        this.props.noteKey,
        "notes"
      );
      this.setState({
        text: note.text,
        tag: note.tag,
        note: note,
      });
      textArea.value = note.notes;
      let { styleType, color } = this.highlightUtil.getHighlightValue(
        note.color || "background-#FEF3CD"
      );
      this.props.handleHighlight({
        styleType,
        color,
      });
    } else {
      let docs = getIframeDoc(this.props.currentBook.format);
      let text = "";
      for (let i = 0; i < docs.length; i++) {
        let doc = docs[i];
        if (!doc) continue;
        text = doc.getSelection()?.toString() || "";
        if (text) {
          break;
        }
      }
      if (!text) return;

      text = text.replace(/\s\s/g, "");
      text = text.replace(/\r/g, "");
      text = text.replace(/\n/g, "");
      text = text.replace(/\t/g, "");
      text = text.replace(/\f/g, "");
      this.setState({ text });
    }
  }
  handleTag = (tag: string[]) => {
    this.setState({ tag });
  };

  handleNoteClick = (event: Event) => {
    this.props.handleNoteKey((event.target as any).dataset.key);
    this.props.handleMenuMode("note");
    this.props.handleOpenMenu(true);
  };
  async createNote() {
    let notes = (document.querySelector(".editor-box") as HTMLInputElement)
      .value;

    if (this.props.noteKey) {
      let newNote = await DatabaseService.getRecord(
        this.props.noteKey,
        "notes"
      );
      newNote.notes = notes;
      newNote.tag = this.state.tag;
      newNote.color =
        this.highlightUtil.formatHighlightValue(this.props.highlight) ||
        newNote.color;
      DatabaseService.updateRecord(newNote, "notes").then(() => {
        this.props.handleOpenMenu(false);
        this.props.handleFetchNotes();
        this.props.handleMenuMode("");
        this.props.handleNoteKey("");
        this.props.handleShowPopupNote(false);
        if (this.props.htmlBook && this.props.htmlBook.rendition) {
          this.props.htmlBook.rendition.removeOneNote(
            this.props.noteKey,
            this.props.chapterDocIndex
          );
          this.props.htmlBook.rendition.createOneNote(
            newNote,
            this.handleNoteClick
          );
        }
      });
    } else {
      let cfi = JSON.stringify(
        ConfigService.getObjectConfig(
          this.props.currentBook.key,
          "recordLocation",
          {}
        )
      );
      if (
        this.props.currentBook.format === "PDF" &&
        !ConfigService.getAllListConfig("convertPDFBooks").includes(
          this.props.currentBook.key
        )
      ) {
        let bookLocation = this.props.htmlBook.rendition.getPositionByChapter(
          this.props.chapterDocIndex
        );
        cfi = JSON.stringify(bookLocation);
      }
      let bookKey = this.props.currentBook.key;
      let range = JSON.stringify(
        await this.props.htmlBook.rendition.getHightlightCoords(
          this.props.chapterDocIndex
        )
      );

      let percentage = ConfigService.getObjectConfig(
        this.props.currentBook.key,
        "recordLocation",
        {}
      ).percentage
        ? ConfigService.getObjectConfig(
            this.props.currentBook.key,
            "recordLocation",
            {}
          ).percentage
        : "0";

      let color =
        this.highlightUtil.formatHighlightValue(this.props.highlight) ||
        "background-#FEF3CD";
      let tag = this.state.tag;

      let note = new Note(
        bookKey,
        this.props.chapter,
        this.props.chapterDocIndex,
        this.state.text,
        cfi,
        range,
        notes,
        percentage,
        color,
        tag
      );
      DatabaseService.saveRecord(note, "notes").then(async () => {
        this.props.handleOpenMenu(false);
        this.props.handleFetchNotes();
        this.props.handleMenuMode("");
        await this.props.htmlBook.rendition.createOneNote(
          note,
          this.handleNoteClick
        );
        // Auto-sync note to enabled destinations
        let noteSyncManager = new NoteSyncManager(
          DatabaseService,
          ConfigService
        );
        noteSyncManager.syncNote(note, bookKey);
      });
    }
  }
  handleUpdateHighlight = () => {};
  handleClose = () => {
    if (this.props.noteKey) {
      DatabaseService.deleteRecord(this.props.noteKey, "notes").then(() => {
        toast.success(this.props.t("Deletion successful"));
        this.props.handleMenuMode("");
        this.props.handleFetchNotes();
        this.props.handleNoteKey("");
        if (this.props.htmlBook && this.props.htmlBook.rendition) {
          this.props.htmlBook.rendition.removeOneNote(
            this.props.noteKey,
            this.props.chapterDocIndex
          );
        }

        this.props.handleOpenMenu(false);
        this.props.handleShowPopupNote(false);
      });
    } else {
      this.props.handleOpenMenu(false);
      this.props.handleMenuMode("");
      this.props.handleNoteKey("");
    }
  };

  render() {
    const colorOptionProps = {
      handleDigest: this.handleUpdateHighlight,
      isEdit: true,
      noteItem: this.state.note,
    };
    let note = this.state.note;

    const renderNoteEditor = () => {
      return (
        <div className="note-editor">
          <div className="note-original-text">{this.state.text}</div>
          <div className="editor-box-parent">
            <textarea
              className="editor-box"
              style={{ height: "calc(100% - 90px)" }}
              onKeyDown={(event) => {
                if (
                  event.key === "Enter" &&
                  (event.ctrlKey || event.metaKey) &&
                  !(event.nativeEvent as any).isComposing
                ) {
                  event.preventDefault();
                  this.createNote();
                }
              }}
            />
          </div>
          <ColorOption {...(colorOptionProps as any)} />
          <div
            className="note-tags"
            style={{
              position: "absolute",
              bottom: "35px",
              height: "40px",
              width: "calc(100% - 40px)",
            }}
          >
            <NoteTag
              {...({
                handleTag: this.handleTag,
                tag: this.props.noteKey && note ? note.tag : [],
              } as any)}
            />
          </div>

          <div className="note-button-container">
            <span
              className="book-manage-title"
              onClick={() => {
                copy(this.state.text);
                toast.success(this.props.t("Copying successful"));
              }}
            >
              <Trans>Copy quotes</Trans>
            </span>
            <span
              className="book-manage-title"
              onClick={() => {
                this.handleClose();
              }}
            >
              {this.props.noteKey ? (
                <Trans>Delete</Trans>
              ) : (
                <Trans>Cancel</Trans>
              )}
            </span>
            <span
              className="book-manage-title"
              onClick={() => {
                this.createNote();
              }}
            >
              <Trans>Confirm</Trans>
            </span>
          </div>
        </div>
      );
    };
    return renderNoteEditor();
  }
}
export default PopupNote;
