import BookModel from "../../../models/Book";
import PluginModel from "../../../models/Plugin";
export interface PopupDictProps {
  originalText: string;
  originalSentence: string;
  plugins: PluginModel[];
  isAuthed: boolean;
  currentBook: BookModel;
  handleOpenMenu: (isOpenMenu: boolean) => void;
  handleMenuMode: (menu: string) => void;
  handleFetchPlugins: () => void;
  handleSetting: (isShow: boolean) => void;
  handleSettingMode: (settingMode: string) => void;
  t: (title: string) => string;
}
export interface PopupDictState {
  dictText: string;
  word: string;
  prototype: string;
  dictService: string;
  dictTarget: string;
  dictSource: string;
  isAddNew: boolean;
  isShowUrl: boolean;
  aiAnswer: string;
  isAiWaiting: boolean;
}
