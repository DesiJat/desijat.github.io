import BookModel from "../../models/Book";
import { RouteComponentProps } from "react-router";

export interface BookItemProps extends RouteComponentProps<any> {
  book: BookModel;
  percentage: number;
  currentBook: BookModel;
  isOpenActionDialog: boolean;
  isSelectBook: boolean;
  isSelected: boolean;
  selectedBooks: string[];
  refreshBookKey: string;
  allBooks?: BookModel[];
  bookIndex?: number;
  handleRefreshBookCover: (key: string) => void;
  handleSelectBook: (isSelectBook: boolean) => void;
  handleReadingBook: (book: BookModel) => void;
  handleEditDialog: (isShow: boolean) => void;
  handleDeleteDialog: (isShow: boolean) => void;
  handleAddDialog: (isShow: boolean) => void;
  handleActionDialog: (isShowActionDialog: boolean) => void;

  t: (title: string) => string;
  handleFetchBooks: () => void;
  handleSelectedBooks: (selectedBooks: string[]) => void;
}
export interface BookItemState {
  isHover: boolean;

  isDeleteDialog: boolean;
  isFavorite: boolean;
  direction: string;
  left: number;
  top: number;
  cover: string;
  isCoverExist: boolean;
  isBookOffline: boolean;
}
