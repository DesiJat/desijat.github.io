export { default } from "./component";
