import BookModel from "../../models/Book";
import HtmlBook from "../../models/HtmlBook";

export interface ViewerProps {
  book: BookModel;
  rendition: any;
  currentBook: BookModel;

  menuMode: string;
  htmlBook: HtmlBook;
  isShow: boolean;
  readerMode: string;
  isOpenMenu: boolean;
  isAuthed: boolean;
  isNavLocked: boolean;
  isSettingLocked: boolean;
  isHideBackground: boolean;
  defaultSyncOption: string;
  scale: string;
  margin: string;
  handleRenderBookFunc: (renderBookFunc: () => void) => void;
  renderNoteFunc: () => void;
  handleFetchAuthed: () => void;
  t: (title: string) => string;
  handleReadingState: (isReading: boolean) => void;
  handleReadingBook: (book: BookModel) => void;
  handleHtmlBook: (htmlBook: HtmlBook | null) => void;
  handleLeaveReader: (position: string) => void;
  handleEnterReader: (position: string) => void;
  handleFetchBooks: () => void;
  handleFetchNotes: () => void;
  handleFetchPlugins: () => void;
  handleFetchBookmarks: () => void;
  handleNoteKey: (key: string) => void;
  handleOpenMenu: (isOpenMenu: boolean) => void;
  handleMenuMode: (menu: string) => void;
  handleReaderMode: (readerMode: string) => void;
  handleCurrentChapter: (currentChapter: string) => void;
  handleCurrentChapterIndex: (currentChapterIndex: number) => void;
  handlePercentage: (percentage: number) => void;
  handleFetchPercentage: (book: BookModel) => void;
  handleScale: (scale: string) => void;
  renderBookFunc: () => void;
  handleBackgroundColor: (color: string) => void;
}
export interface ViewerState {
  key: string;
  isFirst: boolean;
  isTouch: boolean;
  chapterTitle: string;
  isDisablePopup: boolean;
  chapter: string;
  pageOffset: string;
  pageWidth: string;
  chapterDocIndex: number;
  cfiRange: any;
  contents: any;
  rect: any;
  rendition: any;
}
