import NoteModel from "../../models/Note";
import BookmarkModel from "../../models/Bookmark";
import HtmlBookModel from "../../models/HtmlBook";
import { ConfigService } from "../../assets/lib/kookit-extra-browser.min";
import DatabaseService from "../../utils/storage/databaseService";
import ConfigUtil from "../../utils/file/configUtil";
import Note from "../../models/Note";
import Bookmark from "../../models/Bookmark";
import { HighlightValue } from "../../utils/common";

export function handleNotes(notes: NoteModel[]) {
  return { type: "HANDLE_NOTES", payload: notes };
}
export function handleHighlights(highlights: NoteModel[]) {
  return { type: "HANDLE_HIGHLIGHTS", payload: highlights };
}
export function handleOriginalText(originalText: string) {
  return { type: "HANDLE_ORIGINAL_TEXT", payload: originalText };
}
export function handleQuoteText(quoteText: string) {
  return { type: "HANDLE_QUOTE_TEXT", payload: quoteText };
}
export function handleOriginalSentence(originalSentence: string) {
  return { type: "HANDLE_ORIGINAL_SENTENCE", payload: originalSentence };
}
export function handleHighlight(highlight: HighlightValue) {
  return { type: "HANDLE_HIGHLIGHT", payload: highlight };
}
export function handleConvertDialog(isConvertOpen: boolean) {
  return { type: "HANDLE_CONVERT_DIALOG", payload: isConvertOpen };
}
export function handlePdfCropDialog(isPdfCropOpen: boolean) {
  return { type: "HANDLE_PDF_CROP_DIALOG", payload: isPdfCropOpen };
}
export function handleSpeechDialog(isSpeechOpen: boolean) {
  return { type: "HANDLE_SPEECH_DIALOG", payload: isSpeechOpen };
}
export function handleAnnotationDialog(isAnnotationOpen: boolean) {
  return { type: "HANDLE_ANNOTATION_DIALOG", payload: isAnnotationOpen };
}
export function handleSpeechStartText(speechStartText: string) {
  return { type: "HANDLE_SPEECH_START_TEXT", payload: speechStartText };
}
export function handleSpeechAutoStart(isSpeechAutoStart: boolean) {
  return { type: "HANDLE_SPEECH_AUTO_START", payload: isSpeechAutoStart };
}
export function handleBookmarks(bookmarks: BookmarkModel[]) {
  return { type: "HANDLE_BOOKMARKS", payload: bookmarks };
}
export function handleHtmlBook(htmlBook: HtmlBookModel) {
  return { type: "HANDLE_HTML_BOOK", payload: htmlBook };
}
export function handleCurrentChapter(currentChapter: string) {
  return { type: "HANDLE_CURRENT_CHAPTER", payload: currentChapter };
}
export function handleCurrentChapterIndex(currentChapterIndex: number) {
  return { type: "HANDLE_CURRENT_CHAPTER_INDEX", payload: currentChapterIndex };
}
export function handleJumpPosition(jumpPosition: object | null) {
  return { type: "HANDLE_JUMP_POSITION", payload: jumpPosition };
}
export function handleChapters(chapters: any) {
  return { type: "HANDLE_CHAPTERS", payload: chapters };
}
export function handleNoteKey(key: string) {
  return { type: "HANDLE_NOTE_KEY", payload: key };
}
export function handleReaderMode(readerMode: string) {
  return { type: "HANDLE_READER_MODE", payload: readerMode };
}
export function handleScale(scale: string) {
  return { type: "HANDLE_SCALE", payload: scale };
}
export function handleMargin(margin: string) {
  return { type: "HANDLE_MARGIN", payload: margin };
}
export function handleBackgroundColor(backgroundColor: string) {
  return { type: "HANDLE_BACKGROUND_COLOR", payload: backgroundColor };
}
export function handleReaderBackgroundImage(readerBackgroundImage: string) {
  return {
    type: "HANDLE_READER_BACKGROUND_IMAGE",
    payload: readerBackgroundImage,
  };
}
export function handleNavLock(isNavLocked: boolean) {
  return { type: "HANDLE_NAV_LOCK", payload: isNavLocked };
}
export function handleSettingLock(isSettingLocked: boolean) {
  return { type: "HANDLE_SETTING_LOCK", payload: isSettingLocked };
}
export function handleHideFooter(isHideFooter: boolean) {
  return { type: "HANDLE_HIDE_FOOTER", payload: isHideFooter };
}
export function handleHideHeader(isHideHeader: boolean) {
  return { type: "HANDLE_HIDE_HEADER", payload: isHideHeader };
}
export function handleHideBackground(isHideBackground: boolean) {
  return { type: "HANDLE_HIDE_BACKGROUND", payload: isHideBackground };
}
export function handleShowBorder(isShowPageBorder: boolean) {
  return { type: "HANDLE_SHOW_BORDER", payload: isShowPageBorder };
}
export function handleTextOrientation(textOrientation: string) {
  return { type: "HANDLE_TEXT_ORIENTATION", payload: textOrientation };
}

export function handleFetchNotes() {
  return async (
    dispatch: (arg0: { type: string; payload: NoteModel[] }) => void
  ) => {
    let noteSortCodeStr =
      ConfigService.getReaderConfig("noteSortCode") || '{"sort":1,"order":2}';
    let noteSortCode = JSON.parse(noteSortCodeStr);
    let sortField = noteSortCode.sort === 1 ? "key" : "percentage";
    let sortOrder = noteSortCode.order === 1 ? "ASC" : "DESC";

    let notes: Note[] = await ConfigUtil.getNotesByBookKeyAndTypeWithSort(
      "",
      "note",
      sortField,
      sortOrder
    );
    let highlights: Note[] = await ConfigUtil.getNotesByBookKeyAndTypeWithSort(
      "",
      "highlight",
      sortField,
      sortOrder
    );
    let deletedBookKeys = ConfigService.getAllListConfig("deletedBooks");
    notes = notes.filter((note) => !deletedBookKeys.includes(note.bookKey));
    highlights = highlights.filter(
      (highlight) => !deletedBookKeys.includes(highlight.bookKey)
    );
    dispatch(handleHighlights(highlights));
    dispatch(handleNotes(notes));
  };
}

export function handleFetchBookmarks() {
  return (
    dispatch: (arg0: { type: string; payload: BookmarkModel[] }) => void
  ) => {
    DatabaseService.getAllRecords("bookmarks").then((bookmarks: Bookmark[]) => {
      let deletedBookKeys = ConfigService.getAllListConfig("deletedBooks");
      bookmarks = bookmarks.filter(
        (bookmark) => !deletedBookKeys.includes(bookmark.bookKey)
      );
      dispatch(handleBookmarks(bookmarks));
    });
  };
}
