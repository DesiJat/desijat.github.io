import toast from "react-hot-toast";
import {
  ConfigService,
  ReaderRequest,
  TokenService,
} from "../../assets/lib/kookit-extra-browser.min";
import i18n from "../../i18n";
import { handleExitApp } from "./common";
import {
  getServerRegion,
  getWebsiteUrl,
  openExternalUrl,
  openInBrowser,
  vexComfirmAsync,
} from "../common";
import { getTempToken } from "./user";
let readerRequest: ReaderRequest | undefined;
let isShowingQuotaAlert = false;
let quotaAlertDismissTime = 0;
export const getTransStream = async (
  text: string,
  from: string,
  to: string,
  onMessage: (result) => void
) => {
  let readerRequest = await getReaderRequest();
  let result = await readerRequest.getTransFetch(
    {
      text,
      from,
      to,
    },
    onMessage
  );
  return result;
};
export const getAnswerStream = async (
  text: string,
  question: string,
  history: any[],
  mode: string,
  onMessage: (result) => void
) => {
  let readerRequest = await getReaderRequest();
  let result = await readerRequest.getAnswerFetch(
    {
      text,
      question,
      history: history.slice(-5),
      mode,
    },
    onMessage
  );
  return result;
};
export const getDictionaryStream = async (
  word: string,
  from: string,
  to: string,
  sentence: string,
  isFullAnalysis: boolean,
  onMessage: (result) => void
) => {
  let readerRequest = await getReaderRequest();
  let result = await readerRequest.getDictionaryFetch(
    {
      word,
      from,
      to,
      sentence,
      is_full_analysis: isFullAnalysis,
    },
    onMessage
  );
  return result;
};
export const getDictionary = async (word: string, from: string, to: string) => {
  let readerRequest = await getReaderRequest();
  let response = await readerRequest.getDictionary({ word, from, to });
  if (response.code === 200) {
    return response;
  } else if (response.code === 401) {
    handleExitApp();
    return;
  } else {
    toast.error(i18n.t("Fetch failed, error code") + ": " + response.msg);
  }
  return response;
};
export const getReaderRequest = async () => {
  if (readerRequest) {
    return readerRequest;
  }
  readerRequest = new ReaderRequest(
    TokenService,
    ConfigService,
    getServerRegion()
  );
  return readerRequest;
};
export const resetReaderRequest = () => {
  readerRequest = undefined;
};
export const getDictText = async (word: string, from: string, to: string) => {
  if (from === "en") {
    from = "eng";
  }
  let res = await getDictionary(word, from, to);
  if (res.code === 200 && res.data && res.data.length > 0) {
    let dictText =
      `<p class="dict-word-type">[${i18n.t("Pronunciations")}]</p>` +
      (res.data[0].pronunciation ? res.data[0].pronunciation : "") +
      (res.data[0].audio &&
        `<div class="audio-container"><audio controls preload="auto"    class="audio-player" controlsList="nodownload noplaybackrate"><source src="${res.data[0].audio}" type="audio/mpeg"></audio></div>`) +
      (res.data[0].form
        ? `<p class="dict-word-type">[${i18n.t("Inflection")}]</p>`
        : "") +
      (res.data[0].form
        ? Array.from(new Set(res.data[0].form)).join(", ")
        : "") +
      res.data[0].meaning
        .map((item) => {
          return (
            (item.type && `<p><p class="dict-word-type">[${item.type}]</p>`) +
            `<div  style="font-weight: bold">${
              item.definition
            }</div><div>${item.examples
              .map((item) => {
                return `<p>${item.sentence}</p>` + `<p>${item.translation}</p>`;
              })
              .join("</div><div>")}</div></p>`
          );
        })
        .join("") +
      (res.data[0].comparison
        ? `<p class="dict-word-type">[${i18n.t("Word comparison")}]</p>`
        : "") +
      (res.data[0].comparison
        ? res.data[0].comparison.map(
            (item) =>
              `<p class="dict-learn-more">${item.word_to_compare}: </p>${item.analysis}`
          )
        : "") +
      `<p class="dict-learn-more">${i18n.t("Generated with AI")}</p>`;
    return dictText;
  } else {
    return "";
  }
};
export const getOcrResult = async (imageBase64: string) => {
  let readerRequest = await getReaderRequest();
  let response = await readerRequest.getOcrResult({
    image_base64: imageBase64,
  });
  if (response.code === 200) {
    return response;
  } else if (response.code === 401) {
    handleExitApp();
    return;
  } else {
    toast.error(i18n.t("Fetch failed, error code") + ": " + response.msg);
  }
  return response;
};
export const getOcrResultV2 = async (file: any) => {
  let readerRequest = await getReaderRequest();
  let response = await readerRequest.getOcrResultV2({
    file,
  });
  if (response.code === 200) {
    return response;
  } else if (response.code === 401) {
    handleExitApp();
    return;
  } else {
    toast.error(i18n.t("Fetch failed, error code") + ": " + response.msg);
  }
  return response;
};
export const getTTSAudio = async (
  text: string,
  language: string,
  voice: string,
  speed: number,
  pitch: number,
  isFirst: boolean
) => {
  let readerRequest = await getReaderRequest();
  let response = await readerRequest.getTTSAudio({
    text,
    language,
    voice,
    speed,
    pitch,
    is_first: isFirst,
  });
  if (response.code === 200) {
    return response;
  } else if (response.code === 401) {
    handleExitApp();
    return;
  } else if (response.code === 20009) {
    const now = Date.now();
    const timeSinceDismiss = now - quotaAlertDismissTime;

    if (!isShowingQuotaAlert && timeSinceDismiss >= 10000 && response.data) {
      isShowingQuotaAlert = true;
      if (response.data.user_type === "pro") {
        let result = await vexComfirmAsync(
          i18n.t(
            "You have exhausted your daily free AI voice character quota. Please purchase more quota to continue using this feature or wait until the quota resets. You can also use other TTS voices instead."
          ) +
            " " +
            (response.data && response.data.ttl
              ? i18n.t("Your quota will be reset in", {
                  ttl: (response.data.ttl / 3600).toFixed(1),
                })
              : ""),
          "Purchase more quota"
        );
        if (result) {
          isShowingQuotaAlert = false;
          quotaAlertDismissTime = Date.now();
          openExternalUrl(
            getWebsiteUrl() +
              (ConfigService.getReaderConfig("lang").startsWith("zh")
                ? "/zh"
                : "/en") +
              "/tts-quota"
          );
        } else {
          isShowingQuotaAlert = false;
          quotaAlertDismissTime = Date.now();
        }
      } else {
        let result = await vexComfirmAsync(
          i18n.t(
            "Please upgrade to Pro to unlock more daily free quota or wait until the quota resets. You can also use other TTS voices instead."
          ) +
            " " +
            (response.data && response.data.ttl
              ? i18n.t("Your quota will be reset in", {
                  ttl: (response.data.ttl / 3600).toFixed(1),
                })
              : ""),
          "Upgrade to Pro"
        );
        if (result) {
          isShowingQuotaAlert = false;
          quotaAlertDismissTime = Date.now();
          let response = await getTempToken();
          if (response.code === 200) {
            let tempToken = response.data.access_token;
            let deviceUuid = await TokenService.getFingerprint();
            openInBrowser(
              getWebsiteUrl() +
                (ConfigService.getReaderConfig("lang").startsWith("zh")
                  ? "/zh"
                  : "/en") +
                "/pricing?temp_token=" +
                tempToken +
                "&device_uuid=" +
                deviceUuid
            );
          }
        } else {
          isShowingQuotaAlert = false;
          quotaAlertDismissTime = Date.now();
        }
      }
    }
    return response;
  } else {
    toast.error(i18n.t("Fetch failed, error code") + ": " + response.msg);
  }
  return null;
};
export const getBatchTrans = async (
  texts: string[],
  from: string,
  to: string
) => {
  let readerRequest = await getReaderRequest();
  let response = await readerRequest.getBatchTrans({ texts, from, to });
  if (response.code === 200) {
    return response;
  } else if (response.code === 401) {
    handleExitApp();
    return;
  } else {
    toast.error(i18n.t("Fetch failed, error code") + ": " + response.msg);
  }
  return response;
};
export const getWordDefinitions = async (
  texts: string[],
  level: string,
  lang: string
) => {
  let readerRequest = await getReaderRequest();
  let response = await readerRequest.analyzeText({ texts, level, lang });
  if (response.code === 200) {
    return response;
  } else if (response.code === 401) {
    handleExitApp();
    return;
  } else {
    toast.error(i18n.t("Fetch failed, error code") + ": " + response.msg);
  }
  return response;
};
export const getBookMetadata = async (name: string, author: string) => {
  let readerRequest = await getReaderRequest();
  let response = await readerRequest.getBookMetadata({ name, author });
  if (response.code === 200) {
    return response;
  } else if (response.code === 401) {
    handleExitApp();
    return;
  } else {
    toast.error(i18n.t("Fetch failed, error code") + ": " + response.msg);
  }
  return response;
};
export const getSplitSentence = async (
  texts: { text: string; index: number }[]
) => {
  let readerRequest = await getReaderRequest();
  let response = await readerRequest.getSplitSentence({ texts });
  if (response.code === 200) {
    return response;
  } else if (response.code === 401) {
    handleExitApp();
    return response;
  } else if (response.code === 20009) {
    toast.error(
      i18n.t("You have reached the daily limit for this feature.") +
        " " +
        i18n.t("AI multi-role speech is paused for now.") +
        " " +
        i18n.t("Your quota will be reset in", {
          ttl:
            response.data && response.data.ttl
              ? (response.data.ttl / 3600).toFixed(1)
              : "",
        })
    );
  } else {
    toast.error(i18n.t("Fetch failed, error code") + ": " + response.msg);
  }
  return response;
};
export const detectLanguage = async (text: string) => {
  let readerRequest = await getReaderRequest();
  let response = await readerRequest.detectLanguage({ text });
  if (response.code === 200) {
    return response;
  } else if (response.code === 401) {
    handleExitApp();
    return;
  } else {
    toast.error(i18n.t("Fetch failed, error code") + ": " + response.msg);
  }
  return null;
};
