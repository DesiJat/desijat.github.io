import Book from "../../models/Book";
import DictHistory from "../../models/DictHistory";
import Note from "../../models/Note";
import BookUtil from "./bookUtil";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import {
  ConfigService,
  HighlightUtil,
} from "../../assets/lib/kookit-extra-browser.min";
import { BookHelper } from "../../assets/lib/kookit.min";
import * as Kookit from "../../assets/lib/kookit.min";
import { isElectron } from "react-device-detect";
import i18n from "../../i18n";
import toast from "react-hot-toast";
import { getPdfPassword } from "../common";
declare var window: any;
export type BookExportFormat = "md" | "txt" | "json" | "pdf";
export const BOOK_EXPORT_FORMATS: BookExportFormat[] = [
  "md",
  "txt",
  "json",
  "pdf",
];
export const zipFilesToBlob = (buffers: ArrayBuffer[], names: string[]) => {
  var zip = new JSZip();
  for (let index = 0; index < buffers.length; index++) {
    zip.file(names[index], buffers[index]);
  }
  return zip.generateAsync({ type: "blob" });
};

let year = new Date().getFullYear(),
  month = new Date().getMonth() + 1,
  day = new Date().getDate();

export const exportBooks = async (books: Book[]) => {
  if (isElectron && books.length > 50) {
    const { ipcRenderer } = window.require("electron");
    const fs = window.require("fs");
    const path = window.require("path");
    const exportPath = await ipcRenderer.invoke("select-path");
    if (!exportPath) {
      toast.error(i18n.t("Please select a folder"));
      return false;
    }
    toast.loading(i18n.t("Exporting..."), {
      id: "exporting",
    });

    // 让 UI 有时间渲染 toast
    await new Promise((resolve) => setTimeout(resolve, 100));

    // 逐个获取并写入图书文件
    for (let i = 0; i < books.length; i++) {
      try {
        const book = books[i];
        const bookBuffer: boolean | ArrayBuffer | File =
          await BookUtil.fetchBook(
            book.key,
            book.format.toLowerCase(),
            true,
            book.path
          );

        if (bookBuffer) {
          const fileName = getBookName(book);
          const filePath = path.join(exportPath, fileName);
          // 使用 Promise 包装 writeFile 避免阻塞 UI
          await new Promise((resolve, reject) => {
            fs.writeFile(
              filePath,
              Buffer.from(bookBuffer as ArrayBuffer),
              (err) => {
                if (err) reject(err);
                else resolve(null);
              }
            );
          });
        }
      } catch (error) {
        console.error(`Failed to export book ${books[i].name}:`, error);
        toast.error(i18n.t("Failed to export") + `: ${books[i].name}`);
      }
    }
    toast.success(i18n.t("Export successful"), {
      id: "exporting",
    });
    return true;
  }
  let fetchPromises = BookUtil.fetchAllBooks(books);
  let booksBuffers: any[] = [];

  for (let index = 0; index < fetchPromises.length; index++) {
    booksBuffers.push(await fetchPromises[index]);
  }
  let bookNames = books.map((item) => {
    return getBookName(item);
  });

  saveAs(
    await zipFilesToBlob(booksBuffers, bookNames),
    "KoodoReader-Book-" +
      `${year}-${month <= 9 ? "0" + month : month}-${
        day <= 9 ? "0" + day : day
      }.zip`
  );
};
export const getBookName = (item: Book) => {
  if (ConfigService.getReaderConfig("isExportOriginalName") === "yes") {
    let filename =
      item.path.replace(/\\/g, "/").split("/").pop() ||
      item.name + `.${item.format.toLowerCase()}`;
    return filename;
  }
  return item.name + `.${item.format.toLocaleLowerCase()}`;
};

const getBookExportBaseName = (book: Book): string =>
  sanitizeFileName(book.name);

interface PDFTextItem {
  str?: string;
  transform?: number[];
  width?: number;
  height?: number;
  hasEOL?: boolean;
}

interface PDFHighlight {
  text: string;
  color?: string;
}

interface PDFExportPage {
  pageNumber: number;
  lines: string[];
  highlights: PDFHighlight[];
}

interface BookExportContent {
  text: string;
  pages?: PDFExportPage[];
}

const getPDFItemBounds = (item: PDFTextItem) => {
  const transform = item.transform || [];
  const x = transform[4] || 0;
  const y = transform[5] || 0;
  const height = Math.abs(transform[3] || item.height || 10);
  return {
    left: x,
    right: x + (item.width || 0),
    top: y + height,
    bottom: y,
    height,
  };
};

const reconstructPDFLines = (items: PDFTextItem[]): string[] => {
  const positionedItems = items
    .filter((item) => item.str)
    .map((item) => ({ item, bounds: getPDFItemBounds(item) }))
    .sort((first, second) => {
      const verticalDifference = second.bounds.top - first.bounds.top;
      return Math.abs(verticalDifference) > first.bounds.height * 0.45
        ? verticalDifference
        : first.bounds.left - second.bounds.left;
    });
  const lines: { text: string; top: number; height: number; right: number }[] = [];

  positionedItems.forEach(({ item, bounds }) => {
    const line = lines.find(
      (candidate) =>
        Math.abs(candidate.top - bounds.top) <= Math.max(candidate.height, bounds.height) * 0.45
    );
    if (!line) {
      lines.push({
        text: item.str || "",
        top: bounds.top,
        height: bounds.height,
        right: bounds.right,
      });
      return;
    }
    const gap = bounds.left - line.right;
    const usesIndicScript = /[\u0900-\u097F\u0980-\u09FF\u0A00-\u0A7F\u0A80-\u0AFF\u0B00-\u0B7F\u0B80-\u0BFF\u0C00-\u0C7F\u0C80-\u0CFF\u0D00-\u0D7F]/u.test(
      line.text + (item.str || "")
    );
    const separator = item.hasEOL
      ? "\n"
      : gap > Math.max(bounds.height, 4) * (usesIndicScript ? 1.4 : 0.5)
        ? " "
        : "";
    line.text += separator + (item.str || "");
    line.right = Math.max(line.right, bounds.right);
  });

  return lines
    .sort((first, second) => second.top - first.top)
    .map((line) => line.text.trim())
    .filter(Boolean);
};

const getPDFHighlightText = (
  items: PDFTextItem[],
  annotation: { quadPoints?: number[]; color?: number[] }
): PDFHighlight | null => {
  const points = annotation.quadPoints || [];
  if (points.length < 8) return null;
  const text = Array.from({ length: Math.floor(points.length / 8) }, (_, index) => {
    const quad = points.slice(index * 8, index * 8 + 8);
    const left = Math.min(quad[0], quad[2], quad[4], quad[6]);
    const right = Math.max(quad[0], quad[2], quad[4], quad[6]);
    const bottom = Math.min(quad[1], quad[3], quad[5], quad[7]);
    const top = Math.max(quad[1], quad[3], quad[5], quad[7]);
    return items
      .filter((item) => {
        const bounds = getPDFItemBounds(item);
        return bounds.right >= left && bounds.left <= right && bounds.top >= bottom && bounds.bottom <= top;
      })
      .map((item) => item.str || "")
      .join(" ");
  })
    .join(" ")
    .replace(/\s+([,.;:!?%])/g, "$1")
    .trim();
  if (!text) return null;
  const color = annotation.color?.length === 3
    ? `rgb(${annotation.color.map((value) => Math.round(value * 255)).join(", ")})`
    : undefined;
  return { text, color };
};

const extractPDFText = async (
  book: Book,
  data: ArrayBuffer
): Promise<BookExportContent> => {
  const pdfjsLib = window.pdfjsLib;
  if (!pdfjsLib?.getDocument) {
    throw new Error("PDF text extraction is unavailable");
  }

  const loadingTask = pdfjsLib.getDocument({
    data,
    password: getPdfPassword(book) || undefined,
  });
  const pdf = await loadingTask.promise;
  const pages: PDFExportPage[] = [];
  let hasSelectableText = false;

  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
    const page = await pdf.getPage(pageNumber);
    const textContent = await page.getTextContent();
    const items = textContent.items as PDFTextItem[];
    const lines = reconstructPDFLines(items);
    if (lines.length > 0) hasSelectableText = true;
    const annotations = await page.getAnnotations();
    const highlights = annotations
      .filter((annotation: { subtype?: string }) => annotation.subtype === "Highlight")
      .map((annotation) => getPDFHighlightText(items, annotation))
      .filter((highlight): highlight is PDFHighlight => Boolean(highlight));
    pages.push({ pageNumber, lines, highlights });
  }

  const extractedText = pages
    .map((page) => page.lines.join("\n"))
    .join("\n\n")
    .trim();
  if (hasSelectableText) {
    return {
      pages,
      text: extractedText,
    };
  }
  return {
    pages,
    text: extractedText,
  };
};

const renderBookText = async (book: Book): Promise<BookExportContent> => {
  const result = await BookUtil.fetchBook(
    book.key,
    book.format.toLowerCase(),
    true,
    book.path
  );
  if (!result) throw new Error(`Unable to read ${book.name}`);
  if (book.format.toLowerCase() === "pdf") {
    return extractPDFText(book, result as ArrayBuffer);
  }

  const rendition = BookHelper.getRendition(result, {
    format: book.format,
    readerMode: "",
    charset: book.charset || "",
    animation: "none",
    convertChinese: "",
    bookLayout: "",
    textRules: "",
    codeHighlight: "",
    fullTranslationMode: "no",
    textOrientation: "",
    parserRegex: "",
    isDarkMode: "no",
    isMobile: "no",
    password: "",
    isScannedPDF: "no",
    isKeepPDFBackground: "no",
  }, Kookit);
  const container = document.createElement("div");
  container.style.cssText =
    "position:fixed;left:-10000px;top:0;width:940px;max-height:0;overflow:hidden;";
  document.body.appendChild(container);
  try {
    await rendition.renderTo(container);
    return { text: (container.innerText || container.textContent || "").trim() };
  } finally {
    rendition.removeContent?.();
    container.remove();
  }
};

const bookTextToMarkdown = (book: Book, content: BookExportContent): string => {
  const text = content.pages
    ? content.pages
        .map(
          (page) =>
            `## Page ${page.pageNumber}\n\n${page.lines.join("\n")}\n\n${page.highlights.length ? `> Highlights:\n${page.highlights.map((highlight) => `> ==${highlight.text}==`).join("\n")}\n` : ""}`
        )
        .join("\n\n")
    : content.text;
  const paragraphs = text
    .split(/\n{2,}/)
    .map((paragraph) => paragraph.trim())
    .filter(Boolean)
    .join("\n\n");
  return `# ${book.name}\n\n${book.author ? `**Author:** ${book.author}\n\n` : ""}${paragraphs}\n`;
};

const bookTextToHTML = (book: Book, text: string): string => {
  const body = text
    .split(/\n{2,}/)
    .map((paragraph) => `<p>${escapeHTML(paragraph)}</p>`)
    .join("\n");
  return buildHTMLTemplate(
    escapeHTML(book.name),
    `<h1>${escapeHTML(book.name)}</h1>${book.author ? `<p><em>${escapeHTML(book.author)}</em></p>` : ""}${body}`
  );
};

const exportBookAsBlob = async (
  book: Book,
  format: BookExportFormat
): Promise<Blob> => {
  if (format === "pdf" && book.format.toLowerCase() === "pdf") {
    const result = await BookUtil.fetchBook(
      book.key,
      book.format.toLowerCase(),
      true,
      book.path
    );
    if (!result) throw new Error(`Unable to read ${book.name}`);
    return new Blob([result as ArrayBuffer], { type: "application/pdf" });
  }

  const content = await renderBookText(book);
  if (format === "md") return toBlob(bookTextToMarkdown(book, content), "md");
  if (format === "txt") {
    const text = content.pages
      ? content.pages
          .map(
            (page) =>
              `Page ${page.pageNumber}\n${"-".repeat(12)}\n${page.lines.join("\n")}${page.highlights.length ? `\nHighlights:\n${page.highlights.map((highlight) => `  [${highlight.text}]`).join("\n")}` : ""}`
          )
          .join("\n\n")
      : content.text;
    return toBlob(
      `${book.name}\n${"=".repeat(book.name.length)}\n\n${text}\n`,
      "txt"
    );
  }
  if (format === "json") {
    return new Blob(
      [
        JSON.stringify(
          {
            name: book.name,
            author: book.author,
            format: book.format,
            content: content.text,
            pages: content.pages || [],
          },
          null,
          2
        ),
      ],
      { type: "application/json;charset=UTF-8" }
    );
  }
  return generateHTMLAsPDFBlob(bookTextToHTML(book, content.text));
};

export const exportBooksAs = async (
  books: Book[],
  format: BookExportFormat
): Promise<boolean> => {
  if (books.length === 0) return false;
  const fileDate = `${year}-${month <= 9 ? "0" + month : month}-${day <= 9 ? "0" + day : day}`;
  try {
    if (books.length === 1) {
      const book = books[0];
      saveAs(
        await exportBookAsBlob(book, format),
        `${getBookExportBaseName(book)}.${format}`
      );
      return true;
    }

    const zip = new JSZip();
    for (const book of books) {
      zip.file(
        `${getBookExportBaseName(book)}.${format}`,
        await exportBookAsBlob(book, format)
      );
    }
    saveAs(
      await zip.generateAsync({ type: "blob" }),
      `KoodoReader-Books-${fileDate}.zip`
    );
    return true;
  } catch (error) {
    console.error("Failed to export books:", error);
    toast.error(i18n.t("Failed to export"));
    return false;
  }
};
// 将内容字符串转为 Blob
const toBlob = (content: string, format: string): Blob => {
  const mimeMap: Record<string, string> = {
    md: "text/markdown,charset=UTF-8",
    txt: "text/plain,charset=UTF-8",
    html: "text/html,charset=UTF-8",
    csv: "text/csv,charset=UTF-8",
  };
  return new Blob([content], { type: mimeMap[format] || "text/plain" });
};

// 按书名分组数据，返回 { bookName -> items[] } 映射
const groupByBook = (data: any[]): Record<string, any[]> => {
  const map: Record<string, any[]> = {};
  data.forEach((item) => {
    const key = item.bookName || "Unknown book";
    if (!map[key]) map[key] = [];
    map[key].push(item);
  });
  return map;
};

// 将文件名中不合法的字符替换为下划线
const sanitizeFileName = (name: string): string =>
  name.replace(/[\\/:*?"<>|]/g, "_");

// 根据 format 将 data 转为文本内容
const convertNotesData = (
  data: any[],
  format: "csv" | "md" | "txt" | "html"
): string => {
  if (format === "md") return convertNotesToMarkdown(data);
  if (format === "txt") return convertNotesToTxt(data);
  if (format === "html") return convertNotesToHTML(data);
  return convertArrayToCSV(data);
};

export const exportNotes = async (
  notes: Note[],
  books: Book[],
  format: "csv" | "md" | "txt" | "html" | "pdf" = "csv"
) => {
  let data = notes.map((item) => {
    let book = books.filter((subitem) => subitem.key === item.bookKey)[0];
    let bookName = book ? book.name : "Unknown book";
    let bookAuthor = book ? book.author : "Unknown author";
    let styleType = "background";
    let color = "#FEF3CD";
    if (typeof item.color === "number") {
      let highlightUtil = new HighlightUtil(ConfigService);
      let highlightValue = highlightUtil.convertNumberToHighlightValue(
        item.color
      );
      styleType = highlightValue.styleType;
      color = highlightValue.color;
    } else {
      [styleType, color] = item.color.split("-");
    }
    return {
      ...item,
      date: `${item.date.year}-${
        item.date.month <= 9 ? "0" + item.date.month : item.date.month
      }-${item.date.day <= 9 ? "0" + item.date.day : item.date.day}`,
      tag: item.tag.join(","),
      color,
      styleType,
      bookName: bookName,
      bookAuthor: bookAuthor,
    };
  });
  const fileDate = `${year}-${month <= 9 ? "0" + month : month}-${
    day <= 9 ? "0" + day : day
  }`;

  // 涉及多本书时导出压缩包
  const bookNames = Object.keys(groupByBook(data));
  if (bookNames.length > 1 && format !== "pdf") {
    const zip = new JSZip();
    // 全量文件
    zip.file(`all.${format}`, convertNotesData(data, format));
    // 每本书单独文件
    const bookMap = groupByBook(data);
    Object.entries(bookMap).forEach(([bookName, bookData]) => {
      zip.file(
        `${sanitizeFileName(bookName)}.${format}`,
        convertNotesData(bookData, format)
      );
    });
    saveAs(
      await zip.generateAsync({ type: "blob" }),
      `KoodoReader-Note-${fileDate}.zip`
    );
    return;
  }

  if (bookNames.length > 1 && format === "pdf") {
    const zip = new JSZip();
    // 全量 PDF
    const allPdfBlob = await generateHTMLAsPDFBlob(convertNotesToHTML(data));
    zip.file("all.pdf", allPdfBlob);
    // 每本书单独 PDF
    const bookMap = groupByBook(data);
    for (const [bookName, bookData] of Object.entries(bookMap)) {
      const blob = await generateHTMLAsPDFBlob(convertNotesToHTML(bookData));
      zip.file(`${sanitizeFileName(bookName)}.pdf`, blob);
    }
    saveAs(
      await zip.generateAsync({ type: "blob" }),
      `KoodoReader-Note-${fileDate}.zip`
    );
    return;
  }

  if (format === "md") {
    saveAs(
      toBlob(convertNotesToMarkdown(data), "md"),
      `KoodoReader-Note-${fileDate}.md`
    );
  } else if (format === "txt") {
    saveAs(
      toBlob(convertNotesToTxt(data), "txt"),
      `KoodoReader-Note-${fileDate}.txt`
    );
  } else if (format === "html") {
    saveAs(
      toBlob(convertNotesToHTML(data), "html"),
      `KoodoReader-Note-${fileDate}.html`
    );
  } else if (format === "pdf") {
    await exportHTMLAsPDF(
      convertNotesToHTML(data),
      `KoodoReader-Note-${fileDate}.pdf`
    );
  } else {
    saveAs(
      toBlob(convertArrayToCSV(data), "csv"),
      `KoodoReader-Note-${fileDate}.csv`
    );
  }
};

// 根据 format 将 data 转为文本内容
const convertHighlightsData = (
  data: any[],
  format: "csv" | "md" | "txt" | "html"
): string => {
  if (format === "md") return convertHighlightsToMarkdown(data);
  if (format === "txt") return convertHighlightsToTxt(data);
  if (format === "html") return convertHighlightsToHTML(data);
  return convertArrayToCSV(data);
};

export const exportHighlights = async (
  highlights: Note[],
  books: Book[],
  format: "csv" | "md" | "txt" | "html" | "pdf" = "csv"
) => {
  let data = highlights.map((item) => {
    let book = books.filter((subitem) => subitem.key === item.bookKey)[0];
    let bookName = book ? book.name : "Unknown book";
    let bookAuthor = book ? book.author : "Unknown author";
    let styleType = "background";
    let color = "#FEF3CD";
    if (typeof item.color === "number") {
      let highlightUtil = new HighlightUtil(ConfigService);
      let highlightValue = highlightUtil.convertNumberToHighlightValue(
        item.color
      );
      styleType = highlightValue.styleType;
      color = highlightValue.color;
    } else {
      [styleType, color] = item.color.split("-");
    }

    let highlight = {
      ...item,
      date: `${item.date.year}-${
        item.date.month <= 9 ? "0" + item.date.month : item.date.month
      }-${item.date.day <= 9 ? "0" + item.date.day : item.date.day}`,
      tag: item.tag.join(","),
      color,
      styleType,
      bookName: bookName,
      bookAuthor: bookAuthor,
    };
    const { notes, ...rest } = highlight;
    return rest;
  });
  const fileDate = `${year}-${month <= 9 ? "0" + month : month}-${
    day <= 9 ? "0" + day : day
  }`;

  // 涉及多本书时导出压缩包
  const bookNames = Object.keys(groupByBook(data));
  if (bookNames.length > 1 && format !== "pdf") {
    const zip = new JSZip();
    zip.file(`all.${format}`, convertHighlightsData(data, format));
    const bookMap = groupByBook(data);
    Object.entries(bookMap).forEach(([bookName, bookData]) => {
      zip.file(
        `${sanitizeFileName(bookName)}.${format}`,
        convertHighlightsData(bookData, format)
      );
    });
    saveAs(
      await zip.generateAsync({ type: "blob" }),
      `KoodoReader-Highlight-${fileDate}.zip`
    );
    return;
  }

  if (bookNames.length > 1 && format === "pdf") {
    const zip = new JSZip();
    const allPdfBlob = await generateHTMLAsPDFBlob(
      convertHighlightsToHTML(data)
    );
    zip.file("all.pdf", allPdfBlob);
    const bookMap = groupByBook(data);
    for (const [bookName, bookData] of Object.entries(bookMap)) {
      const blob = await generateHTMLAsPDFBlob(
        convertHighlightsToHTML(bookData)
      );
      zip.file(`${sanitizeFileName(bookName)}.pdf`, blob);
    }
    saveAs(
      await zip.generateAsync({ type: "blob" }),
      `KoodoReader-Highlight-${fileDate}.zip`
    );
    return;
  }

  if (format === "md") {
    saveAs(
      toBlob(convertHighlightsToMarkdown(data), "md"),
      `KoodoReader-Highlight-${fileDate}.md`
    );
  } else if (format === "txt") {
    saveAs(
      toBlob(convertHighlightsToTxt(data), "txt"),
      `KoodoReader-Highlight-${fileDate}.txt`
    );
  } else if (format === "html") {
    saveAs(
      toBlob(convertHighlightsToHTML(data), "html"),
      `KoodoReader-Highlight-${fileDate}.html`
    );
  } else if (format === "pdf") {
    await exportHTMLAsPDF(
      convertHighlightsToHTML(data),
      `KoodoReader-Highlight-${fileDate}.pdf`
    );
  } else {
    saveAs(
      toBlob(convertArrayToCSV(data), "csv"),
      `KoodoReader-Highlight-${fileDate}.csv`
    );
  }
};
export const exportDictionaryHistory = (
  dictHistory: DictHistory[],
  books: Book[]
) => {
  let data = dictHistory.map((item) => {
    let book = books.filter((subitem) => subitem.key === item.bookKey)[0];
    let bookName = book ? book.name : "Unknown book";
    let bookAuthor = book ? book.author : "Unknown author";
    let history = {
      ...item,
      date: `${item.date.year}-${
        item.date.month <= 9 ? "0" + item.date.month : item.date.month
      }-${item.date.day <= 9 ? "0" + item.date.day : item.date.day}`,
      sentence: item.sentence || "",
      bookName: bookName,
      bookAuthor: bookAuthor,
    };
    return history;
  });

  saveAs(
    new Blob([convertArrayToCSV(data)], { type: "text/csv,charset=UTF-8" }),
    "KoodoReader-Dictionary-History-" +
      `${year}-${month <= 9 ? "0" + month : month}-${
        day <= 9 ? "0" + day : day
      }.csv`
  );
};
export const convertArrayToCSV = (array) => {
  let csvContent = "\ufeff";
  csvContent += Object.keys(array[0]).join(",") + "\n";
  array.forEach((item) => {
    csvContent +=
      Object.values(item)
        .map((cell) => {
          if (
            typeof cell === "string" &&
            (cell.includes(",") || cell.includes("\n") || cell.includes("s"))
          ) {
            return '"' + cell.replace(/"/g, '""') + '"';
          } else {
            return cell;
          }
        })
        .join(",") + "\n";
  });
  return csvContent;
};

export const convertNotesToMarkdown = (notes: any[]) => {
  // Group notes by book
  const bookMap: { [key: string]: any[] } = {};
  notes.forEach((note) => {
    const key = note.bookName || "Unknown book";
    if (!bookMap[key]) bookMap[key] = [];
    bookMap[key].push(note);
  });

  let md = `# Koodo Reader - Notes\n\n`;
  Object.entries(bookMap).forEach(([bookName, bookNotes]) => {
    const author = bookNotes[0].bookAuthor || "Unknown author";
    md += `## ${bookName}\n\n`;
    md += `*${author}*\n\n`;
    bookNotes.forEach((note) => {
      if (note.chapter) {
        md += `### ${note.chapter}\n\n`;
      }
      if (note.text) {
        md += `> ${note.text.replace(/\n/g, "\n> ")}\n\n`;
      }
      if (note.notes) {
        md += `**Note:** ${note.notes}\n\n`;
      }
      const meta: string[] = [];
      if (note.date) meta.push(`Date: ${note.date}`);
      if (note.color) meta.push(`Color: ${note.color}`);
      if (note.tag) meta.push(`Tags: ${note.tag}`);
      if (meta.length > 0) {
        md += `*${meta.join(" | ")}*\n\n`;
      }
      md += `---\n\n`;
    });
  });
  return md;
};

export const convertNotesToTxt = (notes: any[]) => {
  // Group notes by book
  const bookMap: { [key: string]: any[] } = {};
  notes.forEach((note) => {
    const key = note.bookName || "Unknown book";
    if (!bookMap[key]) bookMap[key] = [];
    bookMap[key].push(note);
  });

  let txt = `Koodo Reader - Notes\n${"=".repeat(40)}\n\n`;
  Object.entries(bookMap).forEach(([bookName, bookNotes]) => {
    const author = bookNotes[0].bookAuthor || "Unknown author";
    txt += `Book: ${bookName}\n`;
    txt += `Author: ${author}\n`;
    txt += `${"-".repeat(40)}\n\n`;
    bookNotes.forEach((note) => {
      if (note.chapter) {
        txt += `Chapter: ${note.chapter}\n`;
      }
      if (note.text) {
        txt += `Text: ${note.text}\n`;
      }
      if (note.notes) {
        txt += `Note: ${note.notes}\n`;
      }
      if (note.date) txt += `Date: ${note.date}\n`;
      if (note.color) txt += `Color: ${note.color}\n`;
      if (note.tag) txt += `Tags: ${note.tag}\n`;
      txt += `\n`;
    });
    txt += `\n`;
  });
  return txt;
};

export const convertHighlightsToMarkdown = (highlights: any[]) => {
  // Group highlights by book
  const bookMap: { [key: string]: any[] } = {};
  highlights.forEach((highlight) => {
    const key = highlight.bookName || "Unknown book";
    if (!bookMap[key]) bookMap[key] = [];
    bookMap[key].push(highlight);
  });

  let md = `# Koodo Reader - Highlights\n\n`;
  Object.entries(bookMap).forEach(([bookName, bookHighlights]) => {
    const author = bookHighlights[0].bookAuthor || "Unknown author";
    md += `## ${bookName}\n\n`;
    md += `*${author}*\n\n`;
    bookHighlights.forEach((highlight) => {
      if (highlight.chapter) {
        md += `### ${highlight.chapter}\n\n`;
      }
      if (highlight.text) {
        md += `> ${highlight.text.replace(/\n/g, "\n> ")}\n\n`;
      }
      const meta: string[] = [];
      if (highlight.date) meta.push(`Date: ${highlight.date}`);
      if (highlight.color) meta.push(`Color: ${highlight.color}`);
      if (highlight.highlightType)
        meta.push(`Type: ${highlight.highlightType}`);
      if (highlight.tag) meta.push(`Tags: ${highlight.tag}`);
      if (meta.length > 0) {
        md += `*${meta.join(" | ")}*\n\n`;
      }
      md += `---\n\n`;
    });
  });
  return md;
};

export const convertHighlightsToTxt = (highlights: any[]) => {
  // Group highlights by book
  const bookMap: { [key: string]: any[] } = {};
  highlights.forEach((highlight) => {
    const key = highlight.bookName || "Unknown book";
    if (!bookMap[key]) bookMap[key] = [];
    bookMap[key].push(highlight);
  });

  let txt = `Koodo Reader - Highlights\n${"=".repeat(40)}\n\n`;
  Object.entries(bookMap).forEach(([bookName, bookHighlights]) => {
    const author = bookHighlights[0].bookAuthor || "Unknown author";
    txt += `Book: ${bookName}\n`;
    txt += `Author: ${author}\n`;
    txt += `${"-".repeat(40)}\n\n`;
    bookHighlights.forEach((highlight) => {
      if (highlight.chapter) {
        txt += `Chapter: ${highlight.chapter}\n`;
      }
      if (highlight.text) {
        txt += `Text: ${highlight.text}\n`;
      }
      if (highlight.date) txt += `Date: ${highlight.date}\n`;
      if (highlight.color) txt += `Color: ${highlight.color}\n`;
      if (highlight.highlightType) txt += `Type: ${highlight.highlightType}\n`;
      if (highlight.tag) txt += `Tags: ${highlight.tag}\n`;
      txt += `\n`;
    });
    txt += `\n`;
  });
  return txt;
};

const buildHTMLTemplate = (title: string, bodyContent: string): string => {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${title}</title>
  <style>
    body { font-family: Georgia, serif; max-width: 860px; margin: 40px auto; padding: 0 20px; color: #222; line-height: 1.7; }
    h1 { font-size: 1.8em; border-bottom: 2px solid #444; padding-bottom: 8px; }
    h2 { font-size: 1.4em; margin-top: 2em; color: #333; }
    h3 { font-size: 1.1em; color: #555; margin-top: 1.2em; }
    blockquote { border-left: 4px solid #aaa; margin: 0.8em 0 0.8em 0; padding: 6px 16px; background: #f9f9f9; color: #444; }
    .note { background: #fffbe6; border-left: 4px solid #f5c518; padding: 6px 14px; margin: 6px 0; }
    .meta { font-size: 0.85em; color: #888; margin: 4px 0 10px; }
    hr { border: none; border-top: 1px solid #ddd; margin: 16px 0; }
  </style>
</head>
<body>
${bodyContent}
</body>
</html>`;
};

export const convertNotesToHTML = (notes: any[]): string => {
  const bookMap: { [key: string]: any[] } = {};
  notes.forEach((note) => {
    const key = note.bookName || "Unknown book";
    if (!bookMap[key]) bookMap[key] = [];
    bookMap[key].push(note);
  });

  let body = `<h1>Koodo Reader - Notes</h1>\n`;
  Object.entries(bookMap).forEach(([bookName, bookNotes]) => {
    const author = bookNotes[0].bookAuthor || "Unknown author";
    body += `<h2>${escapeHTML(bookName)}</h2>\n<p><em>${escapeHTML(author)}</em></p>\n`;
    bookNotes.forEach((note) => {
      if (note.chapter) {
        body += `<h3>${escapeHTML(note.chapter)}</h3>\n`;
      }
      if (note.text) {
        body += `<blockquote>${escapeHTML(note.text)}</blockquote>\n`;
      }
      if (note.notes) {
        body += `<div class="note"><strong>Note:</strong> ${escapeHTML(note.notes)}</div>\n`;
      }
      const meta: string[] = [];
      if (note.date) meta.push(`Date: ${note.date}`);
      if (note.color) meta.push(`Color: ${note.color}`);
      if (note.tag) meta.push(`Tags: ${note.tag}`);
      if (meta.length > 0) {
        body += `<p class="meta">${meta.join(" &nbsp;|&nbsp; ")}</p>\n`;
      }
      body += `<hr />\n`;
    });
  });
  return buildHTMLTemplate("Koodo Reader - Notes", body);
};

export const convertHighlightsToHTML = (highlights: any[]): string => {
  const bookMap: { [key: string]: any[] } = {};
  highlights.forEach((highlight) => {
    const key = highlight.bookName || "Unknown book";
    if (!bookMap[key]) bookMap[key] = [];
    bookMap[key].push(highlight);
  });

  let body = `<h1>Koodo Reader - Highlights</h1>\n`;
  Object.entries(bookMap).forEach(([bookName, bookHighlights]) => {
    const author = bookHighlights[0].bookAuthor || "Unknown author";
    body += `<h2>${escapeHTML(bookName)}</h2>\n<p><em>${escapeHTML(author)}</em></p>\n`;
    bookHighlights.forEach((highlight) => {
      if (highlight.chapter) {
        body += `<h3>${escapeHTML(highlight.chapter)}</h3>\n`;
      }
      if (highlight.text) {
        body += `<blockquote>${escapeHTML(highlight.text)}</blockquote>\n`;
      }
      const meta: string[] = [];
      if (highlight.date) meta.push(`Date: ${highlight.date}`);
      if (highlight.color) meta.push(`Color: ${highlight.color}`);
      if (highlight.highlightType)
        meta.push(`Type: ${highlight.highlightType}`);
      if (highlight.tag) meta.push(`Tags: ${highlight.tag}`);
      if (meta.length > 0) {
        body += `<p class="meta">${meta.join(" &nbsp;|&nbsp; ")}</p>\n`;
      }
      body += `<hr />\n`;
    });
  });
  return buildHTMLTemplate("Koodo Reader - Highlights", body);
};

const escapeHTML = (str: string): string => {
  if (!str) return "";
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
    .replace(/\n/g, "<br />");
};

const preparePDFExportFrame = async (
  htmlContent: string
): Promise<HTMLIFrameElement> => {
  const iframe = document.createElement("iframe");
  iframe.setAttribute("aria-hidden", "true");
  iframe.style.cssText = [
    "position:fixed",
    "left:-10000px",
    "top:0",
    "width:940px",
    "height:1px",
    "border:0",
    "opacity:0",
    "pointer-events:none",
    "background:#fff",
  ].join(";");
  document.body.appendChild(iframe);

  const iframeDoc = iframe.contentDocument;
  const iframeWin = iframe.contentWindow;

  if (!iframeDoc || !iframeWin) {
    document.body.removeChild(iframe);
    throw new Error("Failed to create PDF export frame");
  }

  iframeDoc.open();
  iframeDoc.write(htmlContent);
  iframeDoc.close();

  if (iframeDoc.fonts?.ready) {
    await iframeDoc.fonts.ready;
  }

  await new Promise<void>((resolve) => {
    iframeWin.requestAnimationFrame(() => resolve());
  });

  const frameHeight = Math.max(
    iframeDoc.documentElement.scrollHeight,
    iframeDoc.body.scrollHeight
  );
  iframe.style.height = `${Math.max(frameHeight, 1)}px`;

  return iframe;
};

// 将 HTML 内容渲染为 PDF 并返回 Blob；库不可用时 fallback 为 HTML Blob
const generateHTMLAsPDFBlob = async (htmlContent: string): Promise<Blob> => {
  const html2canvas = (window as any).html2canvas;

  if (!html2canvas) {
    return new Blob([htmlContent], { type: "text/html,charset=UTF-8" });
  }

  const iframe = await preparePDFExportFrame(htmlContent);
  const iframeDoc = iframe.contentDocument;

  if (!iframeDoc) {
    document.body.removeChild(iframe);
    throw new Error("Failed to access PDF export frame");
  }

  try {
    const captureTarget = iframeDoc.body;
    const captureWidth = Math.max(
      iframeDoc.documentElement.scrollWidth,
      captureTarget.scrollWidth,
      940
    );
    const captureHeight = Math.max(
      iframeDoc.documentElement.scrollHeight,
      captureTarget.scrollHeight
    );

    const canvas = await html2canvas(captureTarget, {
      scale: 2,
      useCORS: true,
      backgroundColor: "#ffffff",
      windowWidth: captureWidth,
      windowHeight: captureHeight,
    });

    const pdfDoc = await window.PDFLib.PDFDocument.create();
    const a4Width = 595.28;
    const a4Height = 841.89;
    const margin = 28.35;

    const imgWidth = a4Width - margin * 2;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    const pageContentHeight = a4Height - margin * 2;

    let remainingHeight = imgHeight;
    let sourceY = 0;

    while (remainingHeight > 0) {
      const sliceHeight = Math.min(remainingHeight, pageContentHeight);
      const srcYpx = (sourceY / imgHeight) * canvas.height;
      const srcHpx = (sliceHeight / imgHeight) * canvas.height;

      const pageCanvas = document.createElement("canvas");
      pageCanvas.width = canvas.width;
      pageCanvas.height = Math.round(srcHpx);
      const ctx = pageCanvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(
          canvas,
          0,
          Math.round(srcYpx),
          canvas.width,
          Math.round(srcHpx),
          0,
          0,
          canvas.width,
          Math.round(srcHpx)
        );
      }

      const image = await pdfDoc.embedJpg(
        pageCanvas.toDataURL("image/jpeg", 0.92)
      );
      const page = pdfDoc.addPage([a4Width, a4Height]);
      page.drawImage(image, {
        x: margin,
        y: a4Height - margin - sliceHeight,
        width: imgWidth,
        height: sliceHeight,
      });

      remainingHeight -= sliceHeight;
      sourceY += sliceHeight;
    }

    const pdfBytes = await pdfDoc.save();
    return new Blob([pdfBytes as BlobPart], { type: "application/pdf" });
  } finally {
    document.body.removeChild(iframe);
  }
};

export const exportHTMLAsPDF = async (
  htmlContent: string,
  fileName: string
): Promise<void> => {
  const blob = await generateHTMLAsPDFBlob(htmlContent);
  // generateHTMLAsPDFBlob fallback 时返回 HTML Blob，调整文件名后缀
  const isHTML = blob.type.startsWith("text/html");
  saveAs(blob, isHTML ? fileName.replace(/\.pdf$/, ".html") : fileName);
};
