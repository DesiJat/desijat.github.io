//list the folders in ./assets/locales
const fs = require("fs");
const path = require("path");
const localesPath = path.join(__dirname, "../src/assets/locales");
const folders = fs.readdirSync(localesPath);
let resources = [];
for (let index = 0; index < folders.length; index++) {
  const folder = folders[index];
  resources.push(`../src/assets/locales/${folder}`);
}
console.info(resources);

// find the missing terms in the english
const zhdataRaw = fs.readFileSync(
  path.join(__dirname, "../src/assets/locales/zh-CN.json"),
  "utf-8"
);
const enDataRaw = fs.readFileSync(
  path.join(__dirname, "../src/assets/locales/en.json"),
  "utf-8"
);
//find the missing terms in the target language
// Step1
const zhData = JSON.parse(zhdataRaw);
const enData = JSON.parse(enDataRaw);
let missingTerms = {};
for (let index = 0; index < Object.keys(zhData).length; index++) {
  const term = Object.keys(zhData)[index];
  if (Object.keys(enData).indexOf(term) === -1) {
    console.info(zhData[term]);
    missingTerms[term] = term;
  }
}
console.info(JSON.stringify(missingTerms));
console.info(Object.keys(zhData).length, Object.keys(enData).length);

// Step2: copy the missing terms to the english file
const mergedObj = Object.assign({}, enData, missingTerms);
fs.writeFileSync(
  path.join(__dirname, "../src/assets/locales/en.json"),
  JSON.stringify(mergedObj, null, 2)
);

// Step3:
// fill out the rest of the terms in the target language
const data = fs.readFileSync(
  path.join(__dirname, "../src/assets/locales/en.json"),
  "utf-8"
);
const referData = JSON.parse(data);
for (let index = 0; index < resources.length; index++) {
  try {
    const resource = resources[index];
    console.info(path.join(__dirname, resource));
    const data = fs.readFileSync(path.join(__dirname, resource), "utf-8");
    const targetData = JSON.parse(data);
    let missingTerms = {};
    for (let index = 0; index < Object.keys(referData).length; index++) {
      const term = Object.keys(referData)[index];
      if (Object.keys(targetData).indexOf(term) === -1) {
        console.info(referData[term]);
        missingTerms[term] = referData[term];
      }
    }
    // console.info(missingTerms);
    const mergedObj = Object.assign({}, targetData, missingTerms);

    fs.writeFileSync(
      path.join(__dirname, resource),
      JSON.stringify(mergedObj, null, 2)
    );
  } catch (error) {
    console.error("Error reading JSON file:", error);
  }
}
